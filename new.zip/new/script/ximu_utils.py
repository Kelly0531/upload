# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 16:44:50 2015

@author: zhangfengyi
"""

import pandas as pd

#输出excel
#listIn: [[sheet,title,dataFrame]......]
def writeReport2(listIn,ProjectName,out_file_Path):
    #print ProjectName
    #print "out_file_Path:",out_file_Path
    #print rawFile
    writer = pd.ExcelWriter(out_file_Path,engine = 'xlsxwriter')
    currentRows = {}

    for table in listIn:
        #print table[0],"----",table[1]
        currentRow = currentRows.get(table[0])
        if currentRow ==None:
            currentRow = 2
        #fileName = out_file_Path+"test\\"+table[1]+".xlsx"
        df_title = pd.DataFrame([table[1]])
        #print out_file_Path
        #print table[1]
        df_title.to_excel(writer,sheet_name = table[0],startrow=currentRow ,startcol = 1, index = False , header = False)
        table[2].to_excel(writer,sheet_name = table[0],startrow=currentRow+2,startcol = 1)


        currentRow = currentRow+table[2].shape[0]+8
        currentRows[table[0]] = currentRow

    writer.save()
    print("Writing Finished: "+out_file_Path)
    
def writeReport(listIn,writeFileName):
    rawFile = writeFileName
    writer = pd.ExcelWriter(rawFile,engine = 'xlsxwriter')
    currentRows = {}

    for table in listIn:
        currentRow = currentRows.get(table[0])
        if currentRow ==None:
            currentRow = 2
        #fileName = out_file_Path+"test\\"+table[1]+".xlsx"
        df_title = pd.DataFrame([table[1]])
        #print out_file_Path
        #print table[1]
        df_title.to_excel(writer,sheet_name = table[0],startrow=currentRow ,startcol = 1, index = False , header = False)
        table[2].to_excel(writer,sheet_name = table[0],startrow=currentRow+2,startcol = 1)


        currentRow = currentRow+table[2].shape[0]+8
        currentRows[table[0]] = currentRow

    writer.save()
    print("Writing Finished: "+rawFile)
    
# 平台订单指标分组计算
def plat_order(df,method,out_df_nm,gb_clm,gb_out_nm,gb_avg_cnt=u'1',gb_nm=u'1',avg_if=0):
    out_df_nm = pd.DataFrame()
    if gb_nm != '1':
        if method == 'nunique':
            out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].nunique()
        if method == 'avg':
            if len(gb_avg_cnt)>1:
                if avg_if == 0:
                    out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].sum()/df.groupby(gb_nm)[gb_avg_cnt].nunique()
                if avg_if == 1:
                    out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].count()/df.groupby(gb_nm)[gb_avg_cnt].nunique()
            else :
                if avg_if == 0:
                    out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].sum()/df.groupby(gb_nm)[gb_clm].count()
                if avg_if == 1:
                    out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].count()/df.groupby(gb_nm)[gb_clm].count()
        if method == 'sum':
            out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].sum()
        if method == 'count':
            out_df_nm[gb_out_nm] = df.groupby(gb_nm)[gb_clm].count()
    if gb_nm == '1':
        if method == 'nunique':
            out_df_nm[gb_out_nm] = [df[gb_clm].nunique()]
        if method == 'avg':
            if len(gb_avg_cnt)>1:
                if avg_if == 0:
                    out_df_nm[gb_out_nm] = [df[gb_clm].sum()/df[gb_avg_cnt].nunique()]
                if avg_if == 1:
                    out_df_nm[gb_out_nm] = [df[gb_clm].count()/df[gb_avg_cnt].nunique()]
            else :
                if avg_if == 0:
                    out_df_nm[gb_out_nm] = [df[gb_clm].sum()/df[gb_clm].count()]
                if avg_if == 1:
                    out_df_nm[gb_out_nm] = [df[gb_clm].count()/df[gb_clm].count()]
        if method == 'sum':
            out_df_nm[gb_out_nm] = [df[gb_clm].sum()]
        if method == 'count':
            out_df_nm[gb_out_nm] = [df[gb_clm].count()]
    out_df_nm = out_df_nm.T
    return out_df_nm.round(2)
    
# 平台历史累计指标分组计算
def plat_calculate(df_in,cnt_col=u'cnt_col',sum_col=u'sum_col',avg_col=u'avg_col',nuq_col=u'nuq_col',
                   group_col=u'group_col',row_name=u'row_name',col_name=u'col_name'):
    df_out = pd.DataFrame()
    cnt_col_list = cnt_col.split(',')
    sum_col_list = sum_col.split(',')
    avg_col_list = avg_col.split(',')
    nuq_col_list = nuq_col.split(',')
    col_name_list = col_name.split(',')
    col_length =[len(cnt_col_list),len(sum_col_list),len(avg_col_list),len(nuq_col_list)]
    if group_col != 'group_col':
        pass
    else:
        if cnt_col != 'cnt_col':
            cnt_col_list_rename_num = col_length[0]
            cnt_col_list_rename = col_name_list[:cnt_col_list_rename_num]
            i = 0
            for col in cnt_col_list:
                df_cnt_col_nm = cnt_col_list_rename[i]
                i+=1
                df_out[df_cnt_col_nm] = [df_in["%s" % (col)].count()]
        if sum_col != 'sum_col':
            sum_col_list_rename_num = sum(col_length[:2])
            sum_col_list_rename = col_name_list[sum(col_length[:1]):sum_col_list_rename_num]
            i = 0
            for col in sum_col_list:
                df_cnt_col_nm = sum_col_list_rename[i]
                i+=1
                df_out[df_cnt_col_nm] = [df_in["%s" % (col)].sum()]
        if avg_col != 'avg_col':
            avg_col_list_rename_num = sum(col_length[:3])
            avg_col_list_rename = col_name_list[sum(col_length[:2]):avg_col_list_rename_num]
            i = 0
            for col in avg_col_list:
                df_cnt_col_nm = avg_col_list_rename[i]
                i+=1
                df_out[df_cnt_col_nm] = [df_in["%s" % (col)].sum()/df_in["%s" % (col)].count()]
        if nuq_col != 'nuq_col':
            nuq_col_list_rename_num = sum(col_length[:4])
            nuq_col_list_rename = col_name_list[sum(col_length[:3]):nuq_col_list_rename_num]
            i = 0
            for col in nuq_col_list:
                df_cnt_col_nm = nuq_col_list_rename[i]
                i+=1
                df_out[df_cnt_col_nm] = [df_in["%s" % (col)].nunique()]
    return df_out

            



def plat_gb(df_in,df_out,df_dict,method=u'sum',gb_nm=u'1',gb_clm=u'1',index_nm=u'index',col_nm=u'col_nm'):
    df_out = pd.DataFrame()
    for k,n in df_dict:
        clm_list = n
        if len(clm_list) > 1:
            df_select =  df_in[(df_in[gb_clm] >= n[0])&(df_in[gb_clm] < n[1])]
        else:
            df_select =  df_in[(df_in[gb_clm] >= n[0])]
        plat_run_bak= plat_order(df=df_select
                      ,method=method
                      ,out_df_nm=u'df_ext'
                      ,gb_clm=gb_clm
                      ,gb_nm=(gb_nm)
                      ,gb_out_nm=k)
        if len(plat_run_bak.columns) == 0:
            pass
        else:
            if df_out.shape[0] != 0:
                df_out = df_out.append(plat_run_bak)
            if df_out.shape[0] == 0:
                df_out = plat_run_bak
    df_out.index.name=index_nm
    df_out.columns.name=col_nm
    return df_out.fillna(0).T


# 按照类型分组统计
def cust_type_gb(df_in,df_out,clm_type=u'1',gb_nm=u'1',gb_clm=u'1',gb_avg_cnt=u'1',method=u'count',index_nm=u'index',col_nm=u'col_nm'):
    df_out = pd.DataFrame()
    clm_type_list =list(set(df_in[clm_type]))
    if clm_type_list != [0]:
        for i in clm_type_list:
            df_ext = plat_order(df=df_in[(df_in[clm_type]==i)]
                              ,method=method
                              ,out_df_nm=u'df_ext'
                              ,gb_clm=gb_clm
                              ,gb_nm=(gb_nm)
                              ,gb_avg_cnt=gb_avg_cnt
                              ,gb_out_nm=i)
            if df_out.shape[0] == 0:
                df_out = df_ext
            else:
                df_out = df_out.append(df_ext)
    df_out.index.name=index_nm
    df_out.columns.name=col_nm
    df_out = df_out.sort_index()
    return df_out.fillna(0)
# 数据合并
def df_merge(df_left,df_right,df_how=u'inner',df_left_on=u'1',df_right_on=u'1'):
    df_final = pd.merge(df_left,df_right,how=df_how,left_on=df_left_on,right_on=df_right_on)
    return df_final
def df_rename(df,table_nm,col_nm,sub_nm,index_nm):
    try:
        df.columns.levels[0]._values[0] = table_nm
        df.columns.levels[1]._values[0] = col_nm
        df.columns.levels[2].name=sub_nm
        df.index.name = index_nm
        return 1
    except:
        return 0

def column_name_convert(value):
    if u"score" in value:
        return value
    value=value.replace(u"avg_order_amt_monthly",u"订单月均金额_自然月")
    value=value.replace(u"avg_order_cnt_monthly",u"订单月均数量_自然月")
    value=value.replace(u"avg_order_amt_dealmonthly",u"订单月均金额_交易月")
    value=value.replace(u"avg_order_cnt_dealmonthly",u"订单月均数量_交易月")
    value=value.replace(u"avg_deal_day_cnt_dealmonthly",u"订单月均交易天数_交易月")
    value=value.replace(u"order_cnt_ret_succ",u"有效订单数")
    value=value.replace(u"order_cnt_return_rate",u"退货率")
    value=value.replace(u"reg_cnt_day",u"注册天数")
    value=value.replace(u"reg_cnt_mth",u"注册月数")
    value=value.replace(u"fst_ord_day",u"首次下单日期")
    value=value.replace(u"fst_ord_mth",u"首次下单月份")
    value=value.replace(u"lst_ord_day",u"最后下单日期")
    value=value.replace(u"lst_ord_mth",u"最后下单月份")
    value=value.replace(u"fst_lst_interval_ord_day",u"在平台间隔天数")
    value=value.replace(u"fst_cnt_day",u"最早下单日期距统计时点天数")
    value=value.replace(u"lst_cnt_day",u"最后下单日期距统计时点天数")
    value=value.replace(u"fst_cnt_mth",u"最早下单日期距统计时点月份数")
    value=value.replace(u"lst_cnt_mth",u"最后下单日期距统计时点月份数")
    value=value.replace(u"fail_",u"失败")
    value=value.replace(u"succ_",u"成功")
    value=value.replace(u"return_",u"退货")
    value=value.replace(u"orther",u"其他")
    value=value.replace(u"order_id_nunique",u"订单数量")
    value=value.replace(u"order_time_m_nunique",u"订单交易月数")
    value=value.replace(u"order_amt_amax",u"订单最大金额")
    value=value.replace(u"order_amt_amin",u"订单最小金额")
    value=value.replace(u"order_amt_sum",u"订单金额汇总")
    value=value.replace(u"order_amt_std",u"订单金额标准差")
    value=value.replace(u"order_amt_average",u"订单平均金额")
    value=value.replace(u"order_time_d_nunique",u"订单交易天数")
    value=value.replace(u"cust2_id_nunique",u"卖家数量")
    value=value.replace(u"_day",u"_按日统计")
    value=value.replace(u"_month",u"_按月统计")
    value=value.replace(u"_amax",u"最大值")
    value=value.replace(u"_amin",u"最小值")
    value=value.replace(u"_std",u"标准差")
    value=value.replace(u"_hsty",u"_历史全量")
    value=value.replace(u"_1mth",u"_近1月")
    value=value.replace(u"_3mth",u"_近3月")
    value=value.replace(u"_6mth",u"_近6月")
    value=value.replace(u"_9mth",u"_近9月")
    value=value.replace(u"_12mth",u"_近1年")
    value=value.replace(u"_24mth",u"_近2年")
    value=value.replace(u"ord_cnt_mth",u"月均订单数量")
    value=value.replace(u"mony_amt_mth",u"月均订单金额")
    value=value.replace(u"ord_cnt_dealmth",u"交易月月均订单数量")
    value=value.replace(u"mony_amt_dealmth",u"交易月月均订单金额")
    value=value.replace(u"day_cnt_dealmth",u"交易日")
    return value







