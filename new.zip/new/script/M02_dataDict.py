# -*- coding:utf-8 -*-
import numpy as np
import pandas as pd

def dataDict(tableDict,outputCsvPath):
    dataDict = pd.DataFrame()
    for k,v in tableDict.iteritems():
        #饱和度
        row_cnt = v.shape[0]
        row_nonnull_rt = (v.count()/row_cnt).reset_index().rename(columns={"index":u"列名",0:u"饱和度"})
        #唯一率
        row_distinct_rt = (v.apply(pd.Series.nunique)/row_cnt).reset_index().rename(columns = {"index":u"列名",0:u"唯一率"})
        #水平数
        row_nonnull = (v.count()).reset_index().rename(columns={"index":u"列名",0:u"水平数"})
        #唯一水平数
        row_distinct = (v.apply(pd.Series.nunique)).reset_index().rename(columns = {"index":u"列名",0:u"唯一水平数"})
        #数据类型
        columns = pd.Series(v.dtypes).reset_index()
        columns.rename(columns={u"index":u"列名",0:u"Python数据类型"},inplace=True)
        columns[u"Python数据类型"]=columns[u"Python数据类型"].apply(str)
        columns[u"HUE数据类型_推测"]=columns[u"Python数据类型"].map({
    "int64":"string",
    "object":"string",
    "float64":"string",
    "datetime64[ns]":"timestamp"
        })

        #columns.drop("index",axis=1,inplace=True)
        columns[u"表名"]=k
        columns = columns.merge(row_nonnull_rt,on=u"列名").merge(row_nonnull,on=u"列名").merge(row_distinct_rt,on=u"列名").merge(row_distinct,on=u"列名")
        columns.loc[(columns[u"饱和度"]==1)&(columns[u"唯一率"]==1),u"是否主键_推测"]=u"Y"
        # 以下是拿出前10条做例子，为什么这么做，可否结合结果说明？
        sample= v.head(10).T
        sc = map(lambda x:"Sample "+str(x+1),list(sample.columns))
        sample.columns = sc
        columns = columns.merge(sample,how="left",left_on=u"列名",right_index=True)
        dataDict = dataDict.append(columns)
    dataDict.to_csv(outputCsvPath,encoding="gbk",index=False)
    print outputCsvPath,u"-------生成完毕!"
