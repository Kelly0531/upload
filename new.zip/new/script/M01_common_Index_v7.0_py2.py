# -*- coding:utf-8 -*-


import numpy as np
import pandas as pd
import os
import shutil
import time
import math as mt
import datetime
from IPython.display import display
import ipywidgets as iw
import matplotlib.pyplot as pyplot

import sys
sys.path.append(u"D:\\数据分析\\工具\\通用数据处理\\版本V3.0\\")
from ximu_utils import plat_order,df_rename,writeReport2,writeReport,column_name_convert,df_merge,plat_calculate
import seaborn


#解决中文乱码问题
from pylab import *
mpl.rcParams['font.sans-serif']=['SimHei']
mpl.rcParams['axes.unicode_minus'] = False



            


#输出字段名标准化——20170525添加

class XimuAna:
    def __init__(self,
    ProjectName,
    out_file_Path,
    df_order,
    df_clients,
    df_order_dtl = "__not_set",
    pres_time="2017-04-18",
    order_id_col = u"订单编号",
    order_date_col = u"订单生成时间",
    order_amt_col = u"子订单商品总金额",
    order_cust_id_col = "买家ID",
    order_cust2_id_col = "__not_set",
    order_sts_col = "__not_set",
    order_profile_cols_list = [],
    order_regn_city = "__not_set",
    order_prodct_id = "__not_set",
    cust_stat = "__not_set",
    cust_typ = "__not_set",
    cust_typ2 = "__not_set",
    cust_regn_city = "__not_set",
    cust_cust_id_col = u"客户ID",
    cust_reg_time_col = u"注册时间",
    cust_profile_cols_list = [],
    order_dtl_id_col = '__not_set',
    order_dtl_prd_id = '__not_set',
    order_dtl_sub_id_col = '__not_set',
    order_dtl_amount = '__not_set',
    order_dtl_category_nm = '__not_set',
    order_dtl_sub_category_nm = '__not_set'
    ):
        self.ProjectName = ProjectName
        self.out_file_Path = out_file_Path
        self.df_order = df_order
        self.df_clients = df_clients
        self.df_order_dtl = df_order_dtl
        self.pres_time = pd.to_datetime(pres_time)
        self.order_id_col = order_id_col
        self.order_date_col = order_date_col
        self.order_amt_col = order_amt_col
        self.order_cust_id_col = order_cust_id_col
        self.order_cust2_id_col = order_cust2_id_col
        self.cust_cust_id_col = cust_cust_id_col
        self.cust_reg_time_col = cust_reg_time_col
        self.pres_month=pd.Period(self.pres_time,'M')
        self.pres_day=pd.to_datetime(self.pres_time)
        self.order_sts_col = order_sts_col
        self.order_regn_city = order_regn_city
        self.order_prodct_id = order_prodct_id
        self.cust_stat = cust_stat
        self.cust_typ = cust_typ
        self.cust_typ2 = cust_typ2
        self.cust_regn_city = cust_regn_city
        self.report_list = []
        self.order_dtl_id_col = order_dtl_id_col
        self.order_dtl_prd_id = order_dtl_prd_id
        self.order_dtl_sub_id_col = order_dtl_sub_id_col
        self.order_dtl_amount = order_dtl_amount
        self.category_nm = order_dtl_category_nm
        self.sub_category_nm = order_dtl_sub_category_nm
        self.cust_profile_cols_list = cust_profile_cols_list
        self.order_profile_cols_list = order_profile_cols_list
        
        self.df_order = self.df_order[self.df_order[order_date_col] <= self.pres_day]


    #返回当前时间字符串
    def getTimestr(self):
        dt=time.localtime(time.time())
        rtime=time.strftime("%Y%m%d%H%M%S",dt)
        return rtime

    #检查输入ID是否匹配
    def idCheck(self):
        size_order = self.df_order.shape[0]
        n_order_id = self.df_order[self.order_id_col].nunique()
        size_cust = self.df_clients.shape[0]
        n_cust_id = self.df_clients[self.cust_cust_id_col].nunique()
        print("Order Table Size:"+ str(size_order))
        print("Order ID unique count:"+ str(n_order_id))
        print("Cust Table Size:"+ str(size_cust))
        print("Cust ID unique count:"+ str(n_cust_id))
        if(size_order != n_order_id or size_cust!=n_cust_id):
            print("Warning! Unequal!")
            return False
        else:
            return True
    #定义方差计算，除数为N
    def std(self,a):
        return np.std(a,ddof = 0)

    #客户宽表生成
    def genCustWide(self,write_excel = True, chinese_colName = True):
        print(self.getTimestr()+"----"+"开始执行")

        ProjectName = self.ProjectName
        out_file_Path = self.out_file_Path
        df_order = self.df_order.copy()
        df_clients = self.df_clients.copy()
        order_id_col = self.order_id_col
        order_date_col = self.order_date_col
        order_amt_col = self.order_amt_col
        order_cust_id_col = self.order_cust_id_col
        order_cust2_id_col = self.order_cust2_id_col
        cust_cust_id_col = self.cust_cust_id_col
        cust_reg_time_col = self.cust_reg_time_col
        order_sts_col = self.order_sts_col

        l1_month= self.pres_month - 1
        l3_month= self.pres_month - 3
        l6_month= self.pres_month - 6
        l9_month= self.pres_month - 9
        l12_month= self.pres_month - 12
        l24_month= self.pres_month - 24
        pres_day = self.pres_day
        pres_month = self.pres_month

        #debug
        print self.pres_month
        print l1_month
        


        df_order["__order_id"]=df_order[order_id_col]
        if self.order_sts_col!=u'__not_set':
            df_order["__order_sts"] = df_order[order_sts_col]
        else:
            df_order["__order_sts"] = 3
        df_order["__order_time"]=pd.to_datetime(df_order[order_date_col])
        df_order["__order_amt"]=df_order[order_amt_col].apply(float)
        df_order["__cust_id"]=df_order[order_cust_id_col]

        if self.order_cust2_id_col!=u'__not_set':
            df_order["__cust2_id"]=df_order[order_cust2_id_col]
        else:
            df_order["__cust2_id"]=1
        df_order["__order_time_m"]=df_order["__order_time"].dt.to_period(freq="M")
        #7.0添加
        df_order["__order_time_m_str"]=df_order["__order_time"].dt.to_period(freq="M").astype("string")
        
        df_order["__order_time_d"]=df_order["__order_time"].dt.to_period(freq="D")
        #7.0添加
        df_order["__order_time_d_str"]=df_order["__order_time"].dt.to_period(freq="D").astype("string")
        
        df_order=df_order[df_order["__order_time_d"]<=self.pres_day]
        df_clients["__cust_id"] = df_clients[cust_cust_id_col]
        df_clients["__reg_time"] = pd.to_datetime(df_clients[cust_reg_time_col])
        df_clients["__reg_time_m"]=df_clients["__reg_time"].dt.to_period(freq="M")
        df_clients["__reg_time_d"]=df_clients["__reg_time"].dt.to_period(freq="D")
        if df_order[df_order["__order_sts"] == 3].shape[0]==0:
            print u"无有效订单，请确认order_sts映射情况：1未成功，2待支付，3成功，4退货"
            return

        df_g1=df_order[df_order["__order_sts"] == 3].groupby("__cust_id")["__order_time"].\
        agg(
            {
            #"__order_amt":[np.max,np.min],
            "__order_time_m":[np.max,np.min]
            })
        #flatten the column

        
        df_g1.columns=df_g1.columns.map('_'.join)
        df_g1=df_g1.reset_index()
        print(self.getTimestr()+"----"+"指标计算")
        #debug:
        self.df_g1 = df_g1
        #首次下单日期
        df_g1["fst_ord_day"] = df_g1["__order_time_m_amin"]#.dt.to_period(freq=u'D')
        #首次下单月份
        df_g1["fst_ord_mth"] = df_g1["__order_time_m_amin"]#.dt.to_period(freq=u'M')
        #最后下单日期
        df_g1["lst_ord_day"] = df_g1["__order_time_m_amax"]#.dt.to_period(freq=u'D')
        #最后下单月份
        df_g1["lst_ord_mth"] = df_g1["__order_time_m_amax"]#.dt.to_period(freq=u'M')
        #在平台间隔天数
        df_g1["fst_lst_interval_ord_day"] = df_g1.lst_ord_day - df_g1.fst_ord_day
        #最早下单日期距统计时点天数
        df_g1["fst_cnt_day"]= (pres_day - df_g1.fst_ord_day).dt.days
        #最后下单日期距统计时点天数
        df_g1["lst_cnt_day"]= (pres_day - df_g1.lst_ord_day).dt.days
        #最早下单日期距统计时点月份数
        df_g1["fst_cnt_mth"] = df_g1["fst_cnt_day"]/30
        #df_g1.loc[pres_day.day<df_g1["fst_ord_day"].dt.day,"fst_cnt_mth"] = df_g1["fst_cnt_mth"]-1
        #最后下单日期距统计时点月份数
        df_g1["lst_cnt_mth"]= df_g1["lst_cnt_day"]/30
        
        df_mask_l1 = (df_order["__order_time_m"]==l1_month)

        df_mask_l3 = ((df_order["__order_time_m"]<=l1_month) &
                    (df_order["__order_time_m"]>=l3_month))

        df_mask_l6 = ((df_order["__order_time_m"]<=l1_month) &
                    (df_order["__order_time_m"]>=l6_month))

        df_mask_l9 = ((df_order["__order_time_m"]<=l1_month) &
                    (df_order["__order_time_m"]>=l9_month))

        df_mask_l12 = ((df_order["__order_time_m"]<=l1_month) &
                    (df_order["__order_time_m"]>=l12_month))

        df_mask_l24 = ((df_order["__order_time_m"]<=l1_month) &
                    (df_order["__order_time_m"]>=l24_month))
        df_mask_hsty = (pd.notnull(df_order["__order_time_m"]))



        mask_dict={
            "1mth":df_mask_l1,
            "3mth":df_mask_l3,
            "6mth":df_mask_l6,
            "9mth":df_mask_l9,
            "12mth":df_mask_l12,
            "24mth":df_mask_l24,
            "hsty":df_mask_hsty
        }

        month_dict={
            "1mth":1,
            "3mth":3,
            "6mth":6,
            "9mth":9,
            "12mth":12,
            "24mth":24
        }

        df_mask_o1 = (df_order["__order_sts"] == 3)

        mask_order_sts={
   #         "fail":df_mask_o0,
            "succ":df_mask_o1,
   #         "return":df_mask_o2,
   #         "orther":df_mask_o3
        }

        first_flg=0
        df_grouped=None
        print(self.getTimestr()+"----"+"逐月金额计算")
        df_month_grp = df_order[df_mask_o1].pivot_table(index = "__cust_id",
                          columns = "__order_time_m_str",values = "__order_amt",
                          aggfunc=[np.sum,pd.Series.count,np.mean]) 
        
        df_month_grp2 = df_order[df_mask_o1].groupby(["__order_time_m_str","__cust_id"])\
                            ["__order_amt"].agg([np.sum,pd.Series.count])
        
        df_month_grp2_1 = df_month_grp2.groupby(level=["__order_time_m_str"]).quantile([0,0.05,0.1,0.25,0.5,0.75,0.9,0.95,1]).reset_index()
        df_month_grp2_p = df_month_grp2_1.pivot_table(index=["__order_time_m_str"],columns=["level_1"],values=["sum","count"],aggfunc=np.min)
        
        df_month_grp2_2 = df_month_grp2.groupby(level=["__order_time_m_str"])["sum"] \
                        .agg([np.sum,pd.Series.count,pd.Series.std])\
                        .rename(columns={"sum":"order_sum_amt","count":"cust_cont","std":"mth_amt_std"})
        df_month_grp2_2.columns = pd.MultiIndex.from_product([["basic"],df_month_grp2_2.columns])
        df_month_grp2_m = df_month_grp2_2.merge(df_month_grp2_p,left_index=True,right_index=True)
        
        print(self.getTimestr()+"----"+"指标循环计算")

        for k_period,v_period in mask_dict.items():
            for k_order_sts,v_order_sts in mask_order_sts.items():
                #处理常规统计
                print(self.getTimestr()+"----"+"指标循环计算："+k_order_sts+","+k_period)
                df_grouped_out = None

                df_grouped_t = df_order.loc[v_period&v_order_sts].groupby("__cust_id")
                agg_dict =  {"__order_id": pd.Series.nunique,
                "__order_amt": [np.sum, np.average,np.max,np.min,self.std],
                "__order_time_m": pd.Series.nunique,
                "__cust2_id": pd.Series.nunique,
                "__order_time_d": pd.Series.nunique}
                if True:
                    agg_dict["__order_amt"] =  [np.sum, np.average,np.max,np.min]
                df_grouped_out = df_grouped_t.agg(agg_dict)
                #20170614新增
                if k_period in month_dict.keys():
                    df_grouped_out["_avg_order_amt_monthly"] = df_grouped_out["__order_amt","sum"]/month_dict[k_period]
                    df_grouped_out["_avg_order_cnt_monthly"] = df_grouped_out["__order_id","nunique"]/month_dict[k_period]
                if k_order_sts == "succ":
                    df_grouped_out["_avg_order_amt_dealmonthly"] = df_grouped_out["__order_amt","sum"]/df_grouped_out["__order_time_m","nunique"]
                    df_grouped_out["_avg_order_cnt_dealmonthly"] = df_grouped_out["__order_id","nunique"]/df_grouped_out["__order_time_m","nunique"]
                    df_grouped_out["_avg_deal_day_cnt_dealmonthly"] = df_grouped_out["__order_time_d","nunique"]/df_grouped_out["__order_time_m","nunique"]
                #列名修改
                df_grouped_out.columns=df_grouped_out.columns.map('_'.join)
                df_grouped_out.columns=k_order_sts+df_grouped_out.columns + '_' + k_period
                df_grouped_out=df_grouped_out.reset_index()
                df_grouped_out=df_grouped_out.rename(columns={'index':'__cust_id'})


                #处理单日统计
                df_grouped_day_out2 = None

                df_grouped_day_t = df_order.loc[v_period&v_order_sts].groupby(["__cust_id","__order_time_d"])
                df_grouped_day_out= df_grouped_day_t.agg({
                        "__order_id":pd.Series.nunique,
                        "__order_amt": [np.sum, np.average,np.max,np.min]
                    }
                )
                df_grouped_day_out.columns=df_grouped_day_out.columns.map('_'.join)
                df_grouped_day_out=df_grouped_day_out.reset_index()
                df_grouped_day_out=df_grouped_day_out.rename(columns={'index':'__cust_id'})
                agg_dict = {
                            "__order_id_nunique": [np.max,np.min,self.std],
                            "__order_amt_sum": [np.max,np.min,self.std]
                        }
                if True:
                    agg_dict["__order_id_nunique"] = [np.max,np.min]
                    agg_dict["__order_amt_sum"] = [np.max,np.min]

                df_grouped_day_g2 = df_grouped_day_out.groupby("__cust_id")
                df_grouped_day_out2 = df_grouped_day_g2.agg(agg_dict)

                #列名修改
                df_grouped_day_out2.columns=df_grouped_day_out2.columns.map('_'.join)
                df_grouped_day_out2.columns=k_order_sts+df_grouped_day_out2.columns + '_' + k_period +'_day'
                df_grouped_day_out2=df_grouped_day_out2.rename(columns={'index':'__cust_id'})
                df_grouped_day_out2=df_grouped_day_out2.reset_index()

                #处理单月统计
                df_grouped_month_out2 = None

                df_grouped_month_t = df_order.loc[v_period&v_order_sts].groupby(["__cust_id","__order_time_m"])
                df_grouped_month_out= df_grouped_month_t.agg({
                        "__order_id":pd.Series.nunique,
                        "__order_amt": [np.sum, np.average,np.max,np.min]
                    }
                )
                df_grouped_month_out.columns=df_grouped_month_out.columns.map('_'.join)
                df_grouped_month_out=df_grouped_month_out.reset_index()
                df_grouped_month_out=df_grouped_month_out.rename(columns={'index':'__cust_id'})

                df_grouped_month_g2 = df_grouped_month_out.groupby("__cust_id")
                agg_dict = {
                            "__order_id_nunique": [np.max,np.min],
                            "__order_amt_sum": [np.max,np.min]
                        }

                if True & (k_period == "hsty") & (k_order_sts == "succ"):
                    agg_dict["__order_id_nunique"] = [np.max,np.min,self.std]
                    agg_dict["__order_amt_sum"] = [np.max,np.min,self.std]

                df_grouped_month_out2 = df_grouped_month_g2.agg(agg_dict)

                #列名修改
                df_grouped_month_out2.columns=df_grouped_month_out2.columns.map('_'.join)
                df_grouped_month_out2.columns=k_order_sts+df_grouped_month_out2.columns + '_' + k_period +'_month'
                df_grouped_month_out2=df_grouped_month_out2.rename(columns={'index':'__cust_id'})
                df_grouped_month_out2=df_grouped_month_out2.reset_index()


                if first_flg == 0 :
                    df_grouped = df_grouped_out.copy()
                    df_grouped = df_grouped.merge(df_grouped_day_out2,how="outer",on="__cust_id")
                    df_grouped = df_grouped.merge(df_grouped_month_out2,how="outer",on="__cust_id")
                    first_flg = 1
                else:
                    df_grouped = df_grouped.merge(df_grouped_out,how="outer",on="__cust_id")
                    df_grouped = df_grouped.merge(df_grouped_day_out2,how="outer",on="__cust_id")
                    df_grouped = df_grouped.merge(df_grouped_month_out2,how="outer",on="__cust_id")


        print u"循环计算结束"
        #df_grouped.to_csv("D:\\User\\zhangfengyi\\common_Index_test.csv")

        #近6月有效订单数
        #df_grouped["order_cnt_ret_succ_6mth"] = df_grouped["succ__order_id_nunique_6mth"].fillna(0)+df_grouped["return__order_id_nunique_6mth"].fillna(0)

        #近6月退货率
        #df_grouped.loc[df_grouped["order_cnt_ret_succ_6mth"]>0 ,"order_cnt_return_rate_6mth"] = (df_grouped["return__order_id_nunique_6mth"].fillna(0))/df_grouped["order_cnt_ret_succ_6mth"]


        #注册天数
        #历史订单std
        #注册时间距统计时点月份数
        #debug:
        

        df_clients["reg_cnt_day"] = (pres_day - df_clients["__reg_time"]).dt.days
        df_clients["reg_cnt_mth"] = df_clients["reg_cnt_day"] / 30
        df_clients.loc[pres_day.day<df_clients["__reg_time_d"].dt.day,"reg_cnt_mth"] = df_clients["reg_cnt_mth"] - 1
        if self.cust_regn_city!=u'__not_set':
            df_clients["regn_city"] = df_clients[self.cust_regn_city]
        else:
            df_clients["regn_city"] = 1

        #join all
        cust_cal_list=[ '__cust_id', '__reg_time', '__reg_time_m',
            '__reg_time_d', 'reg_cnt_day', 'reg_cnt_mth',"regn_city"]

        df_clients_cfilter = df_clients.loc[:,cust_cal_list]

        df_final = df_grouped.merge(df_clients_cfilter,how="outer",on="__cust_id")
        df_final = df_final.merge(df_g1,how="outer",on="__cust_id")

        df_final.columns=df_final.columns.str.replace("__","_")
        #2017年5月26日：空值置0
        for i in df_final.columns:
            if ((u"_sum" in i) or (u"_nunique" in i)) and (u"std" not in i):
                #print i
                df_final[i] = df_final[i].fillna(0)

        df_final_out = df_final.copy()
        df_final_out = df_final_out.merge(self.df_clients,left_on="_cust_id",right_on=self.cust_cust_id_col,how="left")
        custwide_q = df_final_out.quantile([0,0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,1]).T
        print self.getTimestr()+"----",u"开始写入excel"
        if write_excel:
            if chinese_colName:
                cols = pd.Series(df_final_out.columns)
                df_final_out.columns=cols.apply(column_name_convert)
            wname = out_file_Path+ProjectName+u"_客户宽表_"+self.getTimestr()+".xlsx"     
            #df_final_out.to_excel(wname)
            
            writer = pd.ExcelWriter(wname,engine = 'xlsxwriter')
            df_final_out.to_excel(writer,sheet_name = u"客户指标")
            df_month_grp.to_excel(writer,sheet_name = u"逐月金额")
            df_month_grp2_m.to_excel(writer,sheet_name = u"逐月分位")
            custwide_q.to_excel(writer,sheet_name = u"指标分位")
            writer.save()
            print(self.getTimestr()+"----","Writing Finished: "+wname)
        self.cust_wide = df_final_out
        self.df_order = df_order
        self.df_month_grp = df_month_grp
        print "Access Cust Index : Name.cust_wide, Name.df_month_grp"


    def genCreditList(self,
    plat_coop=0.8,
    plat_business_rank=0.5,
    plat_risk_share=0.2,
    plat_stable=0.5,
    is_dw_logic=False,
    is_public_logic=False):
        #政策模拟
        df_order = self.df_order
        df_final = self.cust_wide

        #计算平台增长率
        pres_month=self.pres_month
        plat_period = pres_month-df_order["__order_time_m"].min()
        print u"平台交易期：",str(plat_period),u"个月"
        if plat_period>=24:
            order_mask = (pres_month-df_order["__order_time_m"]>0) \
                        & (pres_month-df_order["__order_time_m"]<=12)
            pre_order_mask = (pres_month-df_order["__order_time_m"]>12) \
                        & (pres_month-df_order["__order_time_m"]<=24)
        elif plat_period>=12:
            order_mask = (pres_month-df_order["__order_time_m"]>0) \
                        & (pres_month-df_order["__order_time_m"]<=6)
            pre_order_mask = (pres_month-df_order["__order_time_m"]>6) \
                        & (pres_month-df_order["__order_time_m"]<=12)
        elif plat_period>=6:
            order_mask = (pres_month-df_order["__order_time_m"]>0) \
                        & (pres_month-df_order["__order_time_m"]<=3)
            pre_order_mask = (pres_month-df_order["__order_time_m"]>3) \
                        & (pres_month-df_order["__order_time_m"]<=6)
        else:
            order_mask = [True]*df_order.shape[0]
            pre_order_mask = [True]*df_order.shape[0]

        order_mask = order_mask& (df_order["__order_sts"]==3)
        pre_order_mask = pre_order_mask& (df_order["__order_sts"]==3)
        order_amt_t = df_order[order_mask]["__order_amt"].sum()+0.0
        pre_order_amt_t = df_order[pre_order_mask]["__order_amt"].sum()+0.0
        plat_increase_rate = order_amt_t/ pre_order_amt_t   -1
        print u"最近交易额：",order_amt_t
        print u"早期交易额：",pre_order_amt_t

        #计算平台客户流失率
        if plat_period>=12:
            cust_mask = (pres_month-df_order["__order_time_m"]>0) \
                            & (pres_month-df_order["__order_time_m"]<=6) &(df_order["__order_sts"]==3)
            pre_cust_mask = (pres_month-df_order["__order_time_m"]>6) \
                            & (pres_month-df_order["__order_time_m"]<=12) &(df_order["__order_sts"]==3)

            now_cust = df_order[cust_mask]["__cust_id"].unique()
            pre_cust = df_order[pre_cust_mask]["__cust_id"].unique()
            now_cust_left = np.intersect1d(pre_cust,now_cust)
            print u"早6月客户数",len(pre_cust)
            print u"近6月留存客户数",len(now_cust_left)
            plat_cust_loss_rate = 1-(len(now_cust_left)+0.0)/len(pre_cust)
        else:
            plat_cust_loss_rate = 0


        if plat_period>=24:
            if plat_increase_rate>0.1:
                plat_increase_rate_score = 2.3
            elif plat_increase_rate>-0.5:
                plat_increase_rate_score=1
            else:
                plat_increase_rate_score=0.2
        elif plat_period>=12:
            if plat_increase_rate>0.2:
                plat_increase_rate_score = 1.8
            elif plat_increase_rate>-0.4:
                plat_increase_rate_score=1
            else:
                plat_increase_rate_score=0.5
        elif plat_period>=6:
            if plat_increase_rate>0.3:
                plat_increase_rate_score = 1.5
            elif plat_increase_rate>-0.3:
                plat_increase_rate_score=1
            else:
                plat_increase_rate_score=0.8

        if plat_cust_loss_rate<0.1:
            plat_cust_loss_rate_score=1
        elif plat_cust_loss_rate<0.2:
            plat_cust_loss_rate_score=0.8
        elif plat_cust_loss_rate<0.3:
            plat_cust_loss_rate_score=0.7
        elif plat_cust_loss_rate<0.5:
            plat_cust_loss_rate_score=0.6
        else:
            plat_cust_loss_rate_score=0.5

        if plat_period<6:
            plat_increase_rate=0
            plat_increase_rate_score=1
            plat_cust_loss_rate=0
            plat_cust_loss_rate_score=1

        print "plat_increase_rate:",plat_increase_rate
        print "plat_increase_rate_score:",plat_increase_rate_score
        print "plat_cust_loss_rate:",plat_cust_loss_rate
        print "plat_cust_loss_rate_score:",plat_cust_loss_rate_score
        print "-------------------------------------"
        #平台注册时间
        reg_cnt_day=df_final.reg_cnt_day
        reg_s1=(reg_cnt_day<=30)
        reg_s2=((reg_cnt_day>30) & (reg_cnt_day<=60))
        reg_s3=((reg_cnt_day>60) & (reg_cnt_day<=90))
        reg_s4=((reg_cnt_day>90) & (reg_cnt_day<=180))
        reg_s5=((reg_cnt_day>180) & (reg_cnt_day<=360))
        reg_s6=((reg_cnt_day>360) & (reg_cnt_day<=720))
        reg_s7=(reg_cnt_day>720)

        df_final.loc[:]["reg_day_score"] = 0
        df_final.loc[reg_s1,"reg_day_score"] = 0
        df_final.loc[reg_s2,"reg_day_score"] = 0.3
        df_final.loc[reg_s3,"reg_day_score"] = 0.8
        df_final.loc[reg_s4,"reg_day_score"] = 1
        df_final.loc[reg_s5,"reg_day_score"] = 1.1
        df_final.loc[reg_s6,"reg_day_score"] = 1.3
        df_final.loc[reg_s7,"reg_day_score"] = 1.5

        print(df_final["reg_day_score"].value_counts())
        if is_dw_logic==False:
            print("-----------------计量逻辑--------------------")
            #近12个月经营情况与平台近12个月经营情况对
            rank_1mth_ordcnt=df_final.succ_order_id_nunique_1mth.rank(ascending=True,pct=True,method="min")
            rank_1mth_ordcnt.name="rank_1mth_ordcnt"
            ranl_1mth_ordamt=df_final.succ_order_amt_sum_1mth.rank(ascending=True,pct=True,method="min")
            ranl_1mth_ordamt.name="ranl_1mth_ordamt"
    
            rank_3mth_ordcnt=df_final.succ_order_id_nunique_3mth.rank(ascending=True,pct=True,method="min")
            rank_3mth_ordcnt.name="rank_3mth_ordcnt"
            ranl_3mth_ordamt=df_final.succ_order_amt_sum_3mth.rank(ascending=True,pct=True,method="min")
            ranl_3mth_ordamt.name="ranl_3mth_ordamt"
    
            rank_6mth_ordcnt=df_final.succ_order_id_nunique_6mth.rank(ascending=True,pct=True,method="min")
            rank_6mth_ordcnt.name="rank_6mth_ordcnt"
            ranl_6mth_ordamt=df_final.succ_order_amt_sum_6mth.rank(ascending=True,pct=True,method="min")
            ranl_6mth_ordamt.name="ranl_6mth_ordamt"
    
            rank_12mth_ordcnt=df_final.succ_order_id_nunique_12mth.rank(ascending=True,pct=True,method="min")
            rank_12mth_ordcnt.name="rank_12mth_ordcnt"
            ranl_12mth_ordamt=df_final.succ_order_amt_sum_12mth.rank(ascending=True,pct=True,method="min")
            ranl_12mth_ordamt.name="ranl_12mth_ordamt"
    
            df_deal_score_pre=pd.concat([
    
                    rank_1mth_ordcnt,
    
                    ranl_1mth_ordamt,
                    rank_3mth_ordcnt,
                    ranl_3mth_ordamt,
                    rank_6mth_ordcnt,
                    ranl_6mth_ordamt,
                    #df_final.succ_order_id_nunique_12mth,
                    rank_12mth_ordcnt,
                    #df_final.succ_order_amt_sum_12mth,
                    ranl_12mth_ordamt
                ],axis=1)
    
            #self.check_df_1206 = df_deal_score_pre
    
            df_deal_score_pre.loc[(rank_1mth_ordcnt>0.6)&(ranl_1mth_ordamt>0.6),"deal_score_1mth"]=1
            df_deal_score_pre.loc[(rank_3mth_ordcnt>0.6)&(ranl_3mth_ordamt>0.6),"deal_score_3mth"]=1
            df_deal_score_pre.loc[(rank_6mth_ordcnt>0.6)&(ranl_6mth_ordamt>0.6),"deal_score_6mth"]=1
            df_deal_score_pre.loc[(rank_12mth_ordcnt>0.6)&(ranl_12mth_ordamt>0.6),"deal_score_12mth"]=1
    
            df_deal_score_pre["deal_score_pre"] = df_deal_score_pre.deal_score_1mth.fillna(0)\
                                                    + df_deal_score_pre.deal_score_3mth.fillna(0) \
                                                    + df_deal_score_pre.deal_score_6mth.fillna(0) \
                                                    + df_deal_score_pre.deal_score_12mth.fillna(0)
    
            deal_s1=(df_deal_score_pre["deal_score_pre"]==0)
            deal_s2=(df_deal_score_pre["deal_score_pre"]==1)
            deal_s3=((df_deal_score_pre["deal_score_pre"]==2) | (df_deal_score_pre["deal_score_pre"]==3))
            deal_s4=(df_deal_score_pre["deal_score_pre"]==4)
    
            df_final.loc[deal_s1,"deal_score"] = 0.3
            df_final.loc[deal_s2,"deal_score"] = 0.7
            df_final.loc[deal_s3,"deal_score"] = 1.1
            df_final.loc[deal_s4,"deal_score"] = 1.2
    
            print(df_final["deal_score"].value_counts())
            print("-------------------------------------")
            
        else:
            print("-----------------数仓逻辑--------------------")
            df_final["deal_score_1mth_rank"] = (df_final.succ_order_id_nunique_1mth + \
                                                df_final.succ_order_amt_sum_1mth*10000)\
                                                .rank(ascending=True,pct=True,method="min")
            df_final["deal_score_3mth_rank"] = (df_final.succ_order_id_nunique_3mth + \
                                                df_final.succ_order_amt_sum_3mth*10000)\
                                                .rank(ascending=True,pct=True,method="min")
            df_final["deal_score_6mth_rank"] = (df_final.succ_order_id_nunique_6mth + \
                                                df_final.succ_order_amt_sum_6mth*10000)\
                                                .rank(ascending=True,pct=True,method="min")
            df_final["deal_score_12mth_rank"] = (df_final.succ_order_id_nunique_12mth + \
                                                df_final.succ_order_amt_sum_12mth*10000)\
                                                .rank(ascending=True,pct=True,method="min")
                                                
            df_final.loc[df_final["deal_score_1mth_rank"]>0.6 ,"deal_score_1mth"]=1
            df_final.loc[df_final["deal_score_3mth_rank"]>0.6,"deal_score_3mth"]=1
            df_final.loc[df_final["deal_score_6mth_rank"]>0.6,"deal_score_6mth"]=1
            df_final.loc[df_final["deal_score_12mth_rank"]>0.6,"deal_score_12mth"]=1
    
            df_final["deal_score_pre"] = df_final.deal_score_1mth.fillna(0)\
                                                    + df_final.deal_score_3mth.fillna(0) \
                                                    + df_final.deal_score_6mth.fillna(0) \
                                                    + df_final.deal_score_12mth.fillna(0)
    
            deal_s1=(df_final["deal_score_pre"]==0)
            deal_s2=(df_final["deal_score_pre"]==1)
            deal_s3=((df_final["deal_score_pre"]==2) | (df_final["deal_score_pre"]==3))
            deal_s4=(df_final["deal_score_pre"]==4)
    
            df_final.loc[deal_s1,"deal_score"] = 0.3
            df_final.loc[deal_s2,"deal_score"] = 0.7
            df_final.loc[deal_s3,"deal_score"] = 1.1
            df_final.loc[deal_s4,"deal_score"] = 1.2
    
            print(df_final["deal_score"].value_counts())
            print("-------------------------------------")                                
        #succ_order_amt_sum_std_hsty_month
        #succ_order_id_nunique_std_hsty_month

        #所有交易各月交易方差由高到低排序
        #以客户实际发生月交易计算排序(无交易月不补0，当方差缺失赋极大值)

        order_amt_dev_rank = df_final.succ_order_amt_sum_std_hsty_month.\
                            rank(ascending=False,pct=True,method="min",na_option="top")
        order_amt_dev_rank.name="order_amt_dev_rank"

        #df_final["order_amt_dev_rank"] = order_amt_dev_rank

        deal_dev_s1 = (order_amt_dev_rank<=0.05)
        deal_dev_s2 = ((order_amt_dev_rank>0.05)&(order_amt_dev_rank<=0.4))
        deal_dev_s3 = ((order_amt_dev_rank>0.4)&(order_amt_dev_rank<=0.8))
        deal_dev_s4 = ((order_amt_dev_rank>0.8)&(order_amt_dev_rank<=0.95))
        deal_dev_s5 = ((order_amt_dev_rank>0.95)&(order_amt_dev_rank<=1))

        df_final.loc[deal_dev_s1,"deal_dex_score"] = 0.1
        df_final.loc[deal_dev_s2,"deal_dex_score"] = 0.5
        df_final.loc[deal_dev_s3,"deal_dex_score"] = 0.9
        df_final.loc[deal_dev_s4,"deal_dex_score"] = 1.5
        df_final.loc[deal_dev_s5,"deal_dex_score"] = 2

        print(df_final["deal_dex_score"].value_counts())
        print("-------------------------------------")
        #所有月交易金额&所有月交易笔数由低到高全量排序（%）
        #（cnt：近有交易笔数；amt:所有交易金额；Px:对应指标的分位数）


        deal_cnt_hsty_rank=(df_final.succ_order_id_nunique_hsty.\
                            rank(ascending=True,pct=True,method="min",na_option="top")/0.2).apply(mt.ceil)
        deal_cnt_hsty_rank.name="deal_cnt_hsty_rank"

        deal_amt_hsty_rank=(df_final.succ_order_amt_sum_hsty.\
                            rank(ascending=True,pct=True,method="min",na_option="top")/0.2).apply(mt.ceil)
        deal_amt_hsty_rank.name="deal_amt_hsty_rank"

        deal_amt_cnt_rank=deal_cnt_hsty_rank+deal_amt_hsty_rank

        df_final["deal_amt_cnt_score"]=None
        df_final.loc[deal_amt_cnt_rank>=9,"deal_amt_cnt_score"]=2
        df_final.loc[(deal_amt_cnt_rank>=8) & pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=1.8
        df_final.loc[(deal_amt_cnt_rank>=7) & pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=1.5
        df_final.loc[(deal_amt_cnt_rank>=6) & pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=0.9
        df_final.loc[(deal_amt_cnt_rank>=5) & pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=0.5
        df_final.loc[(deal_amt_cnt_rank>=4) & pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=0.3
        df_final.loc[pd.isnull(df_final.deal_amt_cnt_score),"deal_amt_cnt_score"]=0.1


        print(df_final.deal_amt_cnt_score.value_counts())
        print("-------------------------------------")

        #近6个月月均交易金额（万）
        #succ_avg_order_amt_monthly_6mth
        if is_public_logic == False:
            df_final["deal_amt_6mth_score"]=None
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>3000000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= -99
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>1000000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.3
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>500000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.5
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>300000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.8
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>200000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>100000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.1
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>50000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.2
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>30000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.3
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>20000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.4
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>10000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.5
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>5000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.6
            df_final.loc[pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.7
        else:
            df_final["deal_amt_6mth_score"]=None
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>3000000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.3
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>1000000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.3
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>500000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.5
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>300000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 0.8
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>200000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>100000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.1
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>50000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.2
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>30000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.3
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>20000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.4
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>10000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.5
            df_final.loc[(df_final.succ_avg_order_amt_monthly_6mth>5000) & pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.6
            df_final.loc[pd.isnull(df_final.deal_amt_6mth_score),"deal_amt_6mth_score"]= 1.7



        print(df_final["deal_amt_6mth_score"].value_counts())
        print("-------------------------------------")
        df_final["final_credit_score_part1"] = df_final["reg_day_score"]*df_final["deal_score"]*df_final["deal_dex_score"]*df_final["deal_amt_cnt_score"]*df_final["deal_amt_6mth_score"]
        df_final["final_credit_score_part1_rank"] = df_final["final_credit_score_part1"].rank(ascending=True,pct=False,method="min",na_option="top")/df_final.shape[0]
        df_final["final_risk_adj_score"] = min([20,20*plat_increase_rate_score*plat_cust_loss_rate_score*plat_coop*plat_business_rank*plat_risk_share*plat_stable])
        df_final["final_credit_score"]=30*df_final["final_credit_score_part1_rank"]+20+30+df_final["final_risk_adj_score"]
        df_final["final_credit_score_rank"]=df_final["final_credit_score"].rank(ascending=True,pct=False,method="min")/df_final["final_credit_score"].count()
        df_final["credit_rank_no"]=None

        #cutOffs=[0.98,0.96,0.92,0.88,0.84,0.8,0.76,0.72,0.68,0.64,0.6,0.52,0.4,0.2,0]
        #20170522 modify: No rank
        cutOffs_score=[98,96,92,88,84,80,76,72,68,64,60,52,40,20,0]
        self.credit_list = df_final
        start_flg=0
        for i in range(0,15):
            if start_flg==0:
                cri=(df_final["final_credit_score"]>=cutOffs_score[i])
                #credit_cri_list.append(cri)
                start_flg=1
            else:
                cri=((df_final["final_credit_score"]>=cutOffs_score[i]) & (df_final["final_credit_score"]<cutOffs_score[i-1]))
            df_final.loc[cri,"credit_rank_no"]= i+1

        print(df_final["credit_rank_no"].value_counts().sort_index())
        print("-------------------------------------")
        print("Access by Name.credit_list")



    #通用分析报告生成
    def genReport(self):

        # 数据桶
        amt_dict = [
             (u'[0,10)',[0,10])
            ,(u'[10,100)',[10,100])
            ,(u'[100,250)',[100,250])
            ,(u'[250,500)',[250,500])
            ,(u'[500,750)',[500,750])
            ,(u'[750,1k)',[750,1000])
            ,(u'[1k,2.5k)',[1000,2500])
            ,(u'[2.5k,5k)',[2500,5000])
            ,(u'[5k,7.5k)',[5000,7500])
            ,(u'[7.5k,1万)',[7500,10000])
            ,(u'[1万,2.5万)',[10000,25000])
            ,(u'[2.5万,5万)',[25000,50000])
            ,(u'[5万,7.5万)',[50000,75000])
            ,(u'[7.5万,10万)',[75000,100000])
            ,(u'[10万,25万)',[100000,250000])
            ,(u'[25万,50万)',[250000,500000])
            ,(u'[50万,75万)',[500000,750000])
            ,(u'[75万,100万)',[750000,1000000])
            ,(u'[100万,1000万)',[1000000,10000000])
            ,(u'[1000万,+)',[10000000,])
            ]
            
        cnt_dict = [
        ('[0,5)',[0,5])
        ,('[5,10)',[5,10])
        ,('[10,20)',[10,20])
        ,('[20,40)',[20,40])
        ,('[40,60)',[40,60])
        ,('[60,80)',[60,80])
        ,('[80,100)',[80,100])
        ,('[100,250)',[100,250])
        ,('[250,500)',[250,500])
        ,('[500,750)',[500,750])
        ,('[750,1k)',[750,1000])
        ,('[1k,2.5k)',[1000,2500])
        ,('[2.5k,5k)',[2500,5000])
        ,('[5k,+)',[5000,])
        ]
        mth_dict = [
            ('[0,6)',[0,6])
            ,('[6,12)',[6,12])
            ,('[12,18)',[12,18])
            ,('[18,24)',[18,24])
            ,('[24,+)',[24,])
        ]

        cnt_bings=[0,5,10,20,40,60,80,100,250,500,750,1000,2500,5000,np.inf]

        df_order = self.df_order
        cust_info = self.df_clients

        print(self.getTimestr()+"----"+u"开始执行")

        ProjectName = self.ProjectName
        out_file_Path = self.out_file_Path
        df_order = self.df_order
        df_clients = self.df_clients
        pres_time = pd.to_datetime(self.pres_time)
        order_id_col = self.order_id_col
        order_date_col = self.order_date_col
        order_amt_col = self.order_amt_col
        order_cust_id_col = self.order_cust_id_col
        order_cust2_id_col = self.order_cust2_id_col
        cust_cust_id_col = self.cust_cust_id_col
        cust_reg_time_col = self.cust_reg_time_col
        order_sts_col = self.order_sts_col
        df_order_dtl = self.df_order_dtl
        order_dtl_id_col = self.order_dtl_id_col
        order_dtl_prd_id = self.order_dtl_prd_id
        order_dtl_sub_id_col = self.order_dtl_sub_id_col
        order_dtl_amount = self.order_dtl_amount
        category_nm = self.category_nm
        sub_category_nm = self.sub_category_nm
        order_prodct_id = self.order_prodct_id
        l1_month= self.pres_month - 1
        l3_month= self.pres_month - 3
        l6_month= self.pres_month - 6
        l9_month= self.pres_month - 9
        l12_month= self.pres_month - 12
        l24_month= self.pres_month - 24
        pres_day = self.pres_day
        pres_month = self.pres_month

        df_order["__order_id"]=df_order[order_id_col]

        #order_sts_col
        if self.order_sts_col!=u'__not_set':
            df_order["__order_sts"] = df_order[order_sts_col]
        else:
            df_order["__order_sts"] = 3
        #order_regn_city
        if self.order_regn_city!=u'__not_set':
            df_order["regn_city"] = df_order[self.order_regn_city]
        else:
            df_order["regn_city"] = 1
        #order_prodct_id
        if self.order_prodct_id!=u'__not_set':
            df_order["prodct_id"] = df_order[self.order_prodct_id]
        else:
            df_order["prodct_id"] = 1
        #cust_stat
        if self.cust_stat!=u'__not_set':
            cust_info["cust_stat"] = cust_info[self.cust_stat]
        else:
            cust_info["cust_stat"] = 1
        #cust_typ
        if self.cust_typ!=u'__not_set':
            cust_info["cust_typ"] = cust_info[self.cust_typ]
        else:
            cust_info["cust_typ"] = 1
        #cust_typ2
        if self.cust_typ2!=u'__not_set':
            cust_info["cust_typ2"] = cust_info[self.cust_typ2]
        else:
            cust_info["cust_typ2"] = 1
        #cust_regn_city
        if self.cust_regn_city!=u'__not_set':
            cust_info["regn_city"] = cust_info[self.cust_regn_city]
        else:
            cust_info["regn_city"] = 1


        bings=[0,10,100,250,500,750,1000,2500,5000,7500,10000,25000,50000,75000,100000,250000,500000,750000,1000000,10000000,np.inf]
        mob_club = [0,6,12,18,24,np.inf]

        df_order["__order_time"]=pd.to_datetime(df_order[order_date_col])
        df_order["__order_amt"]=df_order[order_amt_col]
        df_order["__cust_id"]=df_order[order_cust_id_col]

        if self.order_cust2_id_col!=u'__not_set':
            df_order["__cust2_id"]=df_order[order_cust2_id_col]
        else:
            df_order["__cust2_id"]=1
        df_order["__order_time_m"]=df_order["__order_time"].dt.to_period(freq="M")
        df_order["__order_time_d"]=df_order["__order_time"].dt.to_period(freq="D")
        df_order["__order_time_mm"]=df_order["__order_time_m"].apply(str)
        df_order["__order_time_dd"]=df_order["__order_time"].dt.to_period(freq="D").apply(str)
        df_order["__order_time_qq"]=df_order["__order_time"].dt.to_period(freq="Q").apply(str)
        df_order["__order_time_qq_s"]=df_order["__order_time"].dt.to_period(freq="Q")-2
        max_order_qq = str(df_order["__order_time"].dt.to_period(freq="Q").max()-3)
        df_order["__order_amt_club"] = pd.cut(df_order['__order_amt'],bings,right=False).apply(str)
        df_order=df_order[df_order["__order_time_d"]<=self.pres_day]
        cust_info["__cust_id"] = cust_info[cust_cust_id_col]
        cust_info["__reg_time"] = pd.to_datetime(cust_info[cust_reg_time_col])
        cust_info["__reg_time_m"]=cust_info["__reg_time"].dt.to_period(freq="M")
        cust_info["__reg_time_mm"]=cust_info["__reg_time_m"].apply(str)
        cust_info["__reg_time_d"]=cust_info["__reg_time"].dt.to_period(freq="D")
        cust_info["__reg_time_q"]=cust_info["__reg_time"].dt.to_period(freq="Q")
        cust_info["__reg_time_qq"]=cust_info["__reg_time"].dt.to_period(freq="Q").apply(str)
        cust_info["__mob"] = ((pres_time) - pd.to_datetime(cust_info["__reg_time"]))/np.timedelta64(1,"D")/30
        cust_info['mob_club']=pd.cut(cust_info['__mob'],mob_club,right=False).apply(str)
        df_order_info = df_merge(df_order,cust_info,df_how=u'inner',df_left_on=u'__cust_id',df_right_on=u'__cust_id')
        df_order_suss = df_order[(df_order["__order_sts"]==3)]
        df_order_suss.loc[:,u'__cust_id'] = df_order_suss[u'__cust_id'].apply(str)
        cust_info[u'__cust_id'] = cust_info[u'__cust_id'].apply(str)

        df_order_suss_info = df_order_suss.merge(cust_info,how=u'inner',
                                                 left_on=u'__cust_id',right_on=u'__cust_id')
        self.df_order_suss_info_origin = df_order_suss_info
        df_order_fail = df_order[(df_order["__order_sts"]==1)]
        df_order_retn = df_order[(df_order["__order_sts"]==4)]

        # 2.平台交易概览

        # ---------------------
        # 2.1 平台历史累计交易状况
        starttime = datetime.datetime.now()
        df_201=plat_calculate(df_order_suss,
                        cnt_col=u'__order_id',
                        sum_col=u'__order_amt',
                        avg_col=u'__order_amt',
                        nuq_col=u'__cust_id,__order_time_mm',
                        col_name=u'交易订单数,交易总金额,单均交易额,交易客户数,交易月份数')
        print('2.1 平台历史累计交易状况 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()
        # ---------------------
        # 2.2 平台交易客户活跃性
        # 平台用户汇总
        cust_order_cnt = pd.DataFrame()
        cust_order_cnt['cust_order_mth_cnt'] = df_order_suss.groupby('__cust_id')['__order_time_mm'].nunique()
        cust_order_cnt = cust_order_cnt.reset_index()
        cust_order_cnt_mth = pd.DataFrame()
        cust_order_cnt_mth[u'宽表主体客户数（一般为买家）'] = cust_order_cnt.groupby('cust_order_mth_cnt')['__cust_id'].count()
        cust_order_cnt_mth = cust_order_cnt_mth.T
        # 平台卖家汇总
        seller_order_cnt = pd.DataFrame()
        seller_order_cnt['seller_order_mth_cnt'] = df_order_suss.groupby('__cust2_id')['__order_time_mm'].nunique()
        seller_order_cnt = seller_order_cnt.reset_index()
        seller_order_cnt_mth = pd.DataFrame()
        seller_order_cnt_mth[u'与宽表主体交易客户数（一般为卖家）'] = seller_order_cnt.groupby('seller_order_mth_cnt')['__cust2_id'].count()
        seller_order_cnt_mth = seller_order_cnt_mth.T

        df_202 = cust_order_cnt_mth.append(seller_order_cnt_mth).fillna(0)
        df_202.columns.name=u'有交易月数'
        df_202.index.name=u'客户类型'
        print('2.2 平台交易客户活跃性 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()



        # ---------------------
        # 2.3 平台整体业务水平
        # 买家客户数_月
        plat_101 = plat_order(df=df_order_suss,method=u'nunique',gb_clm=u'__cust_id',gb_out_nm=u'买家客户数',out_df_nm=u'plat_101',gb_nm=u'__order_time_mm')
        # 卖家客户数_月
        plat_102 = plat_order(df=df_order_suss,method=u'nunique',gb_clm=u'__cust2_id',gb_out_nm=u'卖家客户数',out_df_nm=u'plat_102',gb_nm=u'__order_time_mm')
        # 成交订单数_月
        plat_103 = plat_order(df=df_order_suss,method=u'count',gb_clm=u'__order_id',gb_out_nm=u'成交订单数',out_df_nm=u'plat_103',gb_nm=u'__order_time_mm')
        # 未成交订单数_月
        plat_104 = plat_order(df=df_order_fail,method=u'count',gb_clm=u'__order_id',gb_out_nm=u'未成交订单数',out_df_nm=u'plat_104',gb_nm=u'__order_time_mm')
        # 退货订单数_月
        plat_105 = plat_order(df=df_order_retn,method=u'count',gb_clm=u'__order_id',gb_out_nm=u'退货订单数',out_df_nm=u'plat_105',gb_nm=u'__order_time_mm')
        # 总订单数_月
        plat_106 = plat_order(df=df_order,method=u'count',out_df_nm=u'plat_106',gb_clm=u'__order_id',gb_out_nm=u'总订单数',gb_nm=u'__order_time_mm')
        # 成交订单金额_月
        plat_107 = plat_order(df=df_order_suss,method=u'sum',out_df_nm=u'plat_107',gb_clm=u'__order_amt',gb_out_nm=u'成交订单金额',gb_nm=u'__order_time_mm')
        # 未成交订单金额_月
        plat_108 = plat_order(df=df_order_fail,method=u'sum',out_df_nm=u'plat_108',gb_clm=u'__order_amt',gb_out_nm=u'未成交订单金额',gb_nm=u'__order_time_mm')
        # 退货订单金额_月
        plat_109 = plat_order(df=df_order_retn,method=u'sum',out_df_nm=u'plat_109',gb_clm=u'__order_amt',gb_out_nm=u'退货订单金额',gb_nm=u'__order_time_mm')
        # 订单总额_月
        plat_110 = plat_order(df=df_order,method=u'sum',out_df_nm=u'plat_110',gb_clm=u'__order_amt',gb_out_nm=u'订单总额',gb_nm=u'__order_time_mm')
        # 成交订单单均金额_月
        plat_111 = plat_order(df=df_order_suss,method=u'avg',out_df_nm=u'plat_111',gb_clm=u'__order_amt',gb_out_nm=u'成交订单单均金额',gb_nm=u'__order_time_mm')
        # 未成交订单单均金额_月
        plat_112 = plat_order(df=df_order_fail,method=u'avg',out_df_nm=u'plat_112',gb_clm=u'__order_amt',gb_out_nm=u'未成交订单单均金额',gb_nm=u'__order_time_mm')
        # 退货订单单均金额_月
        plat_113 = plat_order(df=df_order_retn,method=u'avg',out_df_nm=u'plat_113',gb_clm=u'__order_amt',gb_out_nm=u'退货订单单均金额',gb_nm=u'__order_time_mm')
        # 整体订单单均金额额_月
        plat_114 = plat_order(df=df_order,method=u'avg',gb_clm=u'__order_amt',gb_out_nm=u'整体订单单均金额额',out_df_nm=u'plat_114',gb_nm=u'__order_time_mm')
        # 买家客均成交订单数_月
        plat_115 = plat_order(df=df_order_suss,method=u'avg',out_df_nm=u'plat_115',gb_clm=u'__order_id',gb_avg_cnt=u'__cust_id',gb_out_nm=u'买家客均成交订单数',gb_nm=u'__order_time_mm',avg_if=1)
        # 卖家客均销售订单数
        plat_116 = plat_order(df=df_order_suss,method=u'avg',out_df_nm=u'plat_116',gb_clm=u'__order_id',gb_avg_cnt=u'__cust2_id',gb_out_nm=u'卖家客均销售订单数',gb_nm=u'__order_time_mm',avg_if=1)
        # 买家客均成交金额_月
        plat_117 = plat_order(df=df_order_suss,method=u'avg',out_df_nm=u'plat_117',gb_clm=u'__order_amt',gb_avg_cnt=u'__cust_id',gb_out_nm=u'买家客均成交金额',gb_nm=u'__order_time_mm')
        # 卖家客均成交金额_月
        plat_118 = plat_order(df=df_order_suss,method=u'avg',out_df_nm=u'plat_118',gb_clm=u'__order_amt',gb_avg_cnt=u'__cust2_id',gb_out_nm=u'卖家客均成交金额',gb_nm=u'__order_time_mm')

        df_203 = pd.DataFrame()
        for i in range(1,19):
            if len(locals()["plat_%s" % (100+i)].columns) == 0:
                pass
            if len(locals()["plat_%s" % (100+i)].columns) > 0:
                if df_203.shape[0]!=0:
                    df_203 = df_203.append(locals()["plat_%s" % (100+i)])
                if df_203.shape[0]==0:
                    df_203 = locals()["plat_%s" % (100+i)]
        df_203.columns.name = u'交易月份数'
        df_203.index.name = u'统计指标'
        print('2.3 平台整体业务水平 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        # ---------------------
        # 2.4 订单金额区间-金额分布
        df_204 = pd.pivot_table(df_order_suss,index=['__order_time_mm'],columns='__order_amt_club',values=['__order_amt']
                    ,aggfunc=[np.sum],fill_value=0,margins=False
                   ).fillna(0)
        df_rename(df_204,table_nm=u"订单金额区间-金额分布",col_nm=u"单笔订单交易金额区间",sub_nm=u'总金额',index_nm=u'交易月份')

        # df_204 = plat_gb(df_in=df_order_suss,df_out=u'plat_run_204',df_dict=amt_dict,method=u'sum',gb_nm=u'__order_time_mm',gb_clm=u'__order_amt',index_nm=u'单笔金额区间',col_nm=u'月份')
        print('2.4 订单金额区间-金额分布 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        # 2.5 订单金额区间-订单数分布
        df_205 = pd.pivot_table(df_order_suss,index=['__order_time_mm'],columns='__order_amt_club',values=['__order_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   ).fillna(0)
        df_rename(df_205,table_nm=u"订单金额区间-订单数分布",col_nm=u"单笔订单交易金额区间",sub_nm=u'订单数',index_nm=u'交易月份')

        # df_205 = plat_gb(df_in=df_order_suss,df_out=u'plat_run_205',df_dict=amt_dict,method=u'count',gb_nm=u'__order_time_mm',gb_clm=u'__order_amt',index_nm=u'单笔金额区间',col_nm=u'月份')
        print('2.5 订单金额区间-订单数分布 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        # ---------------------
        # 2.6 客户月交易金额区间金额分布
        # 客户月交易金额区间分布——原始数据
        plat_206 = plat_order(df=df_order_suss
                            ,method=u'sum'
                            ,out_df_nm=u'plat_206'
                            ,gb_clm=u'__order_amt'
                            ,gb_nm=['__cust_id','__order_time_mm']
                            ,gb_out_nm=u'cust_order_amt_mth').T.reset_index()
        plat_206['amt_club']=pd.cut(plat_206['cust_order_amt_mth'],bings).apply(str)
        df_206 = pd.pivot_table(plat_206,index=['__order_time_mm'],columns='amt_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_206,table_nm=u"客户月交易金额区间客户数分布",col_nm=u"月交易额区间",sub_nm=u'去重客户数',index_nm=u'交易月份')

        # df_206 = plat_gb(df_in=plat_206,df_out=plat_run_206,df_dict=amt_dict,method=u'sum',gb_nm=u'__order_time_mm',gb_clm=u'cust_order_amt_mth',index_nm=u'月交易金额区间',col_nm=u'月份')

        print('2.6 客户月交易金额区间金额分布 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()
        # ---------------------
        # 2.7 客户月交易订单数区间客户数分布
        # 客户月交易金额区间分布——原始数据
        plat_207 = plat_order(df=df_order_suss
                            ,method=u'count'
                            ,out_df_nm=u'plat_207'
                            ,gb_clm=u'__order_amt'
                            ,gb_nm=['__cust_id','__order_time_mm']
                            ,gb_out_nm=u'cust_order_cnt_mth').T.reset_index()

        plat_207['cnt_club']=pd.cut(plat_207['cust_order_cnt_mth'],cnt_bings).apply(str)
        df_207 = pd.pivot_table(plat_207,index=['__order_time_mm'],columns='cnt_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_207,table_nm=u"客户月交易订单数区间客户数分布",col_nm=u"月订单数区间",sub_nm=u'去重客户数',index_nm=u'交易月份')

        # plat_207 = plat_order(df=df_order_suss
        #                     ,method=u'count'
        #                     ,out_df_nm=u'plat_207'
        #                     ,gb_clm=u'__order_amt'
        #                     ,gb_nm=('__cust_id','__order_time_mm')
        #                     ,gb_out_nm=u'cust_order_cnt_mth').T.reset_index()
        # plat_run_207 = pd.DataFrame()
        # df_207 = plat_gb(df_in=plat_207,df_out=plat_run_207,df_dict=cnt_dict,method=u'sum',gb_nm=u'__order_time_mm',gb_clm=u'cust_order_cnt_mth',index_nm=u'月交易金额区间',col_nm=u'月份')
        print('2.7 客户月交易订单数区间订单数分布 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        # 3.1.1 账户状态分布
        df_311 = pd.pivot_table(cust_info,index=['cust_stat'],columns='mob_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_311,table_nm=u"账户状态分布",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'客户状态')

        # df_311 = plat_gb(df_in=cust_info,df_out=u'plat_run_311',df_dict=mth_dict,method=u'count',gb_nm=u'cust_stat',gb_clm=u'__mob',index_nm=u'注册月数',col_nm=u'账户状态')
        # 3.1.2 客户类型1与注册时间分布
        df_312 = pd.pivot_table(cust_info,index=['cust_typ'],columns='mob_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_312,table_nm=u"客户类型1与注册时间分布",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'客户类型1')

        # df_312 = plat_gb(df_in=cust_info,df_out=u'plat_run_312',df_dict=mth_dict,method=u'count',gb_nm=u'cust_typ',gb_clm=u'__mob',index_nm=u'注册月数',col_nm=u'客户类型1')
        # 3.1.3 客户类型2与注册时间分布
        df_313 = pd.pivot_table(cust_info,index=['cust_typ2'],columns='mob_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_313,table_nm=u"客户类型2与注册时间分布",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'客户类型2')

        # df_313 = plat_gb(df_in=cust_info,df_out=u'plat_run_313',df_dict=mth_dict,method=u'count',gb_nm=u'cust_typ2',gb_clm=u'__mob',index_nm=u'注册月数',col_nm=u'客户类型2')
        # 3.1.4 客户状态与客户类型1分类
        df_314 = pd.pivot_table(cust_info,index=['cust_stat'],columns='cust_typ',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_314,table_nm=u"客户状态与客户类型1分类",col_nm=u"客户类型1",sub_nm=u'去重客户数',index_nm=u'客户状态')

        # df_314 = cust_type_gb(df_in=cust_info,df_out=u'cust_run_314',clm_type=u'cust_typ',gb_nm=u'cust_stat',gb_clm=u'__cust_id',method=u'count',index_nm=u'客户类型1',col_nm=u'客户状态')
        # 3.1.5 客户状态与客户类型2分类
        df_315 = pd.pivot_table(cust_info,index=['cust_stat'],columns='cust_typ2',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_315,table_nm=u"客户状态与客户类型2分类",col_nm=u"客户类型2",sub_nm=u'去重客户数',index_nm=u'客户状态')

        # df_315 = cust_type_gb(df_in=cust_info,df_out=u'cust_run_315',clm_type=u'cust_typ2',gb_nm=u'cust_stat',gb_clm=u'__cust_id',method=u'count',index_nm=u'客户类型2',col_nm=u'客户状态')

        print('3.1客户基本属性分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()
        # 3.2.1 城市与客户状态分布
        df_321 = pd.pivot_table(cust_info,index=['cust_stat'],columns='regn_city',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_321,table_nm=u"城市与客户状态分布",col_nm=u"所属城市",sub_nm=u'去重客户数',index_nm=u'客户状态')


        # df_321 = cust_type_gb(df_in=cust_info,df_out=u'cust_run_321',clm_type=u'regn_city',gb_nm=u'cust_stat',gb_clm=u'__cust_id',method=u'count',index_nm=u'所属城市',col_nm=u'客户状态')
        # 3.2.2 城市与客户类型1分布
        df_322 = pd.pivot_table(cust_info,index=['cust_typ'],columns='regn_city',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_322,table_nm=u"城市与客户类型1分布",col_nm=u"所属城市",sub_nm=u'去重客户数',index_nm=u'客户类型1')

        # df_322 = cust_type_gb(df_in=cust_info,df_out=u'cust_run_322',clm_type=u'regn_city',gb_nm=u'cust_typ',gb_clm=u'__cust_id',method=u'count',index_nm=u'所属城市',col_nm=u'客户类型1')
        # 3.2.3 城市与客户类型2分布
        df_323 = pd.pivot_table(cust_info,index=['cust_typ'],columns='regn_city',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_323,table_nm=u"城市与客户类型2分布",col_nm=u"所属城市",sub_nm=u'去重客户数',index_nm=u'客户类型2')

        # df_323 = cust_type_gb(df_in=cust_info,df_out=u'cust_run_323',clm_type=u'regn_city',gb_nm=u'cust_typ2',gb_clm=u'__cust_id',method=u'count',index_nm=u'所属城市',col_nm=u'客户类型2')
        # 3.2.4 城市与客户注册月份数分布
        df_324 = pd.pivot_table(cust_info,index=['regn_city'],columns='mob_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_324,table_nm=u"城市与客户注册月份数分布",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'所属城市')

        # df_324 = plat_gb(df_in=cust_info,df_out=u'plat_run_324',df_dict=mth_dict,method=u'count',gb_nm=u'regn_city',gb_clm=u'__mob',index_nm=u'注册月份',col_nm=u'所属城市')

        # 3.2.5 客户注册地区交易客户数分布
        df_325 = pd.pivot_table(df_order_suss_info,index=[u'regn_city_y'],columns=u'mob_club',values=[u'__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_325,table_nm=u"客户注册地区交易客户数分布",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'注册所属城市')

        # 3.2.6 客户注册地区交易金额分布
        # print df_order_suss_info
        df_326 = pd.pivot_table(df_order_suss_info,index=[u'regn_city_y'],columns=u'mob_club',values=[u'__order_amt']
                    ,aggfunc=[np.sum],fill_value=0
                   )
        df_rename(df_326,table_nm=u"客户注册地区交易金额分布",col_nm=u"注册月份数区间",sub_nm=u'交易金额',index_nm=u'注册所属城市')

        # 3.2.7 客户注册地区交易订单数分布
        df_327 = pd.pivot_table(df_order_suss_info,index=[u'regn_city_y'],columns=u'mob_club',values=[u'__order_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_327,table_nm=u"客户注册地区交易订单数分布",col_nm=u"注册月份数区间",sub_nm=u'交易订单数',index_nm=u'注册所属城市')

        # 3.2.8 客户注册地区交易单均交易额分布
        df_328 = pd.pivot_table(df_order_suss_info,index=[u'regn_city_y'],columns=u'mob_club',values=[u'__order_amt']
                    ,aggfunc=[np.average],fill_value=0
                   )
        df_rename(df_328,table_nm=u"客户注册地区交易单均交易额分布",col_nm=u"注册月份数区间",sub_nm=u'单均交易额',index_nm=u'注册所属城市')


        print('3.2客户地域属性分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()
        # 3.3.1客户生命周期分析
        df_331 = pd.pivot_table(cust_info,index=['__reg_time_qq'],columns='mob_club',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_331,table_nm=u"客户生命周期分析",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'注册季度')

        # df_331 = plat_gb(df_in=cust_info,df_out=u'plat_run_331',df_dict=mth_dict,method=u'count',gb_nm=u'__reg_time_qq',gb_clm=u'__mob',index_nm=u'__mob',col_nm=u'注册季度')

        # 3.3.2客户生命周期-交易月份数分析
        cust_order_cnts = pd.DataFrame()
        cust_order_cnts['cust_order_cnts'] = df_order_suss.groupby('__cust_id')['__order_time_mm'].nunique()
        cust_order_cnts = cust_order_cnts.reset_index()
        cust_order_cnts = pd.merge(cust_info,cust_order_cnts,how='left',left_on='__cust_id',right_on='__cust_id')#.fillna(0)

        df_332 = pd.pivot_table(cust_order_cnts,index=['cust_order_cnts'],columns='mob_club',values=['__cust_id']
                            ,aggfunc=[pd.Series.nunique],fill_value=0
                           ).fillna(0)
        df_rename(df_332,table_nm=u"客户生命周期-交易月份数分析",col_nm=u"注册月份数区间",sub_nm=u'去重客户数',index_nm=u'交易月份数')

        print('3.3客户生命周期分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        # 4.1.1 各客群交易客户数
        df_411 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_411,table_nm=u"客户类型1 各客群交易客户数",col_nm=u"客户类型1 月交易客户数",sub_nm=u'去重客户数',index_nm=u'月份')

        # df_411 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_411',clm_type=u'__order_time_mm',gb_nm=u'cust_typ',gb_clm=u'__cust_id',method=u'nunique',index_nm=u'月份',col_nm=u'客户类型1 月交易客户数')
        # 4.1.2 各客群月订单数额
        df_412 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ',values=['__order_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0
                   )
        df_rename(df_412,table_nm=u"客户类型1 各客群月订单数额",col_nm=u"客户类型1 月订单数",sub_nm=u'订单数',index_nm=u'月份')

        # df_412 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_412',clm_type=u'__order_time_mm',gb_nm=u'cust_typ',gb_clm=u'__order_id',method=u'nunique',index_nm=u'月份',col_nm=u'客户类型1 月订单数')
        # 4.1.3 各客群月交易额
        df_413 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ',values=['__order_amt']
                    ,aggfunc=[np.sum],fill_value=0,margins=False
                   )
        df_rename(df_413,table_nm=u"客户类型1 各客群月交易额",col_nm=u"客户类型1 月订交易金额",sub_nm=u'交易额',index_nm=u'月份')

        # df_413 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_413',clm_type=u'__order_time_mm',gb_nm=u'cust_typ',gb_clm=u'__order_amt',method=u'sum',index_nm=u'月份',col_nm=u'客户类型1 月订交易金额')
        # 4.1.4 各客群月单均价
        df_414 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ',values=['__order_amt']
                    ,aggfunc=[np.average],fill_value=0,margins=False
                   )
        df_rename(df_414,table_nm=u"客户类型1 各客群月单均价",col_nm=u"客户类型1 月单均价",sub_nm=u'月单均价',index_nm=u'月份')

        # df_414 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_414',clm_type=u'__order_time_mm',gb_nm=u'cust_typ',gb_clm=u'__order_amt',gb_avg_cnt=u'__order_id',method=u'avg',index_nm=u'月份',col_nm=u'客户类型1 月单均价')
        # 4.1.5 各客群交易客户数
        df_415 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ2',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_415,table_nm=u"客户类型2 各客群交易客户数",col_nm=u"客户类型2 月交易客户数",sub_nm=u'去重客户数',index_nm=u'月份')

        # df_415 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_415',clm_type=u'__order_time_mm',gb_nm=u'cust_typ2',gb_clm=u'__cust_id',method=u'nunique',index_nm=u'月份',col_nm=u'客户类型2 月交易客户数')
        # 4.1.6 各客群月订单数额
        df_416 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ2',values=['__order_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_416,table_nm=u"客户类型2 各客群月订单数额",col_nm=u"客户类型2 月订单数",sub_nm=u'订单数',index_nm=u'月份')

        # df_416 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_416',clm_type=u'__order_time_mm',gb_nm=u'cust_typ2',gb_clm=u'__order_id',method=u'nunique',index_nm=u'月份',col_nm=u'客户类型2 月订单数')
        # 4.1.7 各客群月交易额
        df_417 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ2',values=['__order_amt']
                    ,aggfunc=[np.sum],fill_value=0,margins=False
                   )
        df_rename(df_417,table_nm=u"客户类型2 各客群月交易额",col_nm=u"客户类型2 月订交易金额",sub_nm=u'交易额',index_nm=u'月份')

        # df_417 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_417',clm_type=u'__order_time_mm',gb_nm=u'cust_typ2',gb_clm=u'__order_amt',method=u'sum',index_nm=u'月份',col_nm=u'客户类型2 月订交易金额')
        # 4.1.8 各客群月单均价
        df_418 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='cust_typ2',values=['__order_amt']
                    ,aggfunc=[np.average],fill_value=0,margins=False
                   )
        df_rename(df_418,table_nm=u"客户类型2 各客群月单均价",col_nm=u"客户类型2 月单均价",sub_nm=u'月单均价',index_nm=u'月份')

        # df_418 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_418',clm_type=u'__order_time_mm',gb_nm=u'cust_typ2',gb_clm=u'__order_amt',gb_avg_cnt=u'__order_id',method=u'avg',index_nm=u'月份',col_nm=u'客户类型2 月单均价')

        print('4.1平台交易客群分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()

        #order_prodct_id

        if order_prodct_id != "__not_set" or type(df_order_dtl) == type(df_order):
            if order_prodct_id != "__not_set" and type(df_order_dtl) == type(df_order):
                print u"order_prodct_id与df_order_dtl同时有效，将以order_prodct_id作为商品类别"
            if order_prodct_id != "__not_set":
                produc_order_info = df_order_suss
                produc_order_info['order_dtl_amount'] = produc_order_info[order_amt_col]
                produc_order_info['order_month_str']  =produc_order_info['__order_time_mm'].astype(str)
                produc_order_info[ order_prodct_id ]=produc_order_info[ order_prodct_id ].fillna(u"缺失")
                ct_nm = [order_prodct_id]
            elif type(df_order_dtl) == type(df_order):
                starttime = datetime.datetime.now()
                if category_nm != '__not_set':
                    if sub_category_nm != '__not_set':
                        ct_nm = ['category_nm','sub_category_nm']
                        df_order_dtl['sub_category_nm'] = df_order_dtl[self.sub_category_nm]
                    else:
                        ct_nm = ['category_nm']
                        df_order_dtl['sub_category_nm'] = 1
                    df_order_dtl['category_nm'] = df_order_dtl[self.category_nm]
                else:
                    df_order_dtl['category_nm'] = 1
                    ct_nm = ['category_nm']
                print('订单明细表判断完毕用时----%sS'%((datetime.datetime.now() - starttime).seconds))
                starttime = datetime.datetime.now()
                df_order_dtl.loc[(df_order_dtl.category_nm.isnull()),'category_nm'] = u'缺失'
                df_order_dtl['order_dtl_id_col'] = df_order_dtl[self.order_dtl_id_col]
                df_order_dtl['order_dtl_amount'] = df_order_dtl[self.order_dtl_amount]

                df_order_suss.loc[:,'order_month_str']=df_order_suss['__order_time_mm'].astype(str)
                produc_order_info =  pd.merge(df_order_suss,df_order_dtl,how=u'inner',left_on=u'__order_id',right_on=u'order_dtl_id_col')
            produc_order_info['amount_club']=pd.cut(produc_order_info['order_dtl_amount'],bings,right=False).apply(str)
            print('订单明细表拼合用时----%sS'%((datetime.datetime.now() - starttime).seconds))
            starttime = datetime.datetime.now()
            # 4.2.1 各商品类别月购买客户数

            df_4201 = pd.pivot_table(produc_order_info,index=['order_month_str'],columns=ct_nm,values=['__cust_id']
                                ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                               )
            df_rename(df_4201,table_nm=u"各商品类目月购买客户数分布(去重)",col_nm=u"去重客户数",sub_nm=u'商品类目',index_nm=u'交易月份')
            # 4.2.2 各商品类别月订单数
            df_4202 = pd.pivot_table(produc_order_info,index=['order_month_str'],columns=ct_nm,values=['__order_id']
                                ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                               )
            df_rename(df_4202,table_nm=u"各商品类目月订单数分布(去重)",col_nm=u"去重订单数",sub_nm=u'商品类目',index_nm=u'交易月份')
            # 4.2.3 各商品类别月交易额
            df_4203 = pd.pivot_table(produc_order_info,index=['order_month_str'],columns=ct_nm,values=['order_dtl_amount']
                                ,aggfunc=[np.sum],fill_value=0,margins=False
                               )
            df_rename(df_4203,table_nm=u"各商品类目月交易额分布",col_nm=u"交易额汇总",sub_nm=u'商品类目',index_nm=u'交易月份')
            # 4.2.4 各商品类别月单均价
            df_4204 = pd.pivot_table(produc_order_info,index=['order_month_str'],columns=ct_nm,values=['order_dtl_amount']
                                ,aggfunc=[np.average],fill_value=0,margins=False
                               )
            df_rename(df_4204,table_nm=u"各商品类目月单均价分布",col_nm=u"金额",sub_nm=u'商品类目',index_nm=u'交易月份')
            # 4.2.5 各商品类别单交易额金额区间订单数分布
            df_4205 = pd.pivot_table(produc_order_info,index=ct_nm,columns=['amount_club'],values=['__order_id']
                                ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                               )
            df_rename(df_4205,table_nm=u"各商品类目交易-订单数分布",col_nm=u"订单数",sub_nm=u'商品类目单笔交易区间',index_nm=u'商品类目')
            # 4.2.6 各商品类别单交易额金额区间金额分布
            df_4206 = pd.pivot_table(produc_order_info,index=ct_nm,columns=['amount_club'],values=['order_dtl_amount']
                                ,aggfunc=[np.sum],fill_value=0,margins=False
                               ).fillna(0)
            df_rename(df_4206,table_nm=u"各商品类目交易-金额分布",col_nm=u"金额总计",sub_nm=u'商品类目单笔交易区间',index_nm=u'商品类目')
            print('4.2平台交易商品分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        else:
            df_4201=pd.DataFrame()
            df_4202=pd.DataFrame()
            df_4203=pd.DataFrame()
            df_4204=pd.DataFrame()
            df_4205=pd.DataFrame()
            df_4206=pd.DataFrame()


        #平台mob
        df_mob1 = df_order_suss_info.pivot_table(index="__reg_time_mm",
                               columns = "__order_mob_bin",values = "__cust_id",aggfunc=pd.Series.nunique)
        df_mob2 = df_order_suss_info.pivot_table(index="__reg_time_mm",
                               columns = "__order_mob_bin",values = "__order_amt",aggfunc=[np.sum,pd.Series.count])
        df_custt_grp = cust_info.groupby([u'__reg_time_mm'] )["__cust_id"].count().reset_index()
        df_custt_grp.columns = pd.MultiIndex.from_product([["base"],df_custt_grp.columns])
        
        df_mob1_2 = df_custt_grp.merge(df_mob1,left_on = "__reg_time_mm",right_on="__reg_time_mm",how="outer")
        df_mob2_2 = df_custt_grp.merge(df_mob2,left_on = [("base","__reg_time_mm")],right_index=True,how="outer")
        # 4.3.1 各区域月客户数
        df_431 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='regn_city_x',values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_431,table_nm=u"各区域月客户数",col_nm=u"交易区域",sub_nm=u'交易客户数',index_nm=u'月份')

        # df_431 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_431',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__cust_id',method=u'nunique',index_nm=u'月份',col_nm=u'各区域月客户数')
        # 4.3.2 各区域月订单数
        df_432 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='regn_city_x',values=['__order_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                   )
        df_rename(df_432,table_nm=u"各区域月订单数",col_nm=u"交易区域",sub_nm=u'订单数',index_nm=u'月份')

        # df_432 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_432',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__order_id',method=u'nunique',index_nm=u'月份',col_nm=u'各区域月订单数')
        # 4.3.3 各区域月交易额
        df_433 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='regn_city_x',values=['__order_amt']
                    ,aggfunc=[np.sum],fill_value=0,margins=False
                   )
        df_rename(df_433,table_nm=u"各区域月交易额",col_nm=u"交易区域",sub_nm=u'交易额',index_nm=u'月份')

       # df_433 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_433',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__order_amt',method=u'sum',index_nm=u'月份',col_nm=u'各区域月交易额')
        # 4.3.4 各区域月单均价
        df_434 = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns='regn_city_x',values=['__order_amt']
                    ,aggfunc=[np.average],fill_value=0,margins=False
                   )
        df_rename(df_434,table_nm=u"各区域月单均价",col_nm=u"交易区域",sub_nm=u'交易额',index_nm=u'月份')

        order_profile_list = []
        order_profile_dict = {}
        for i in self.order_profile_cols_list:
            sheet_name = u"订单属性_" + i
            #客户数
            dict_key = i+u"_客户数"
            order_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns= i ,values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False)
            df_rename(order_profile_dict[dict_key] ,table_nm=u"客户数",col_nm= i,sub_nm=u'交易客户数',index_nm=u'月份')
            order_profile_list.append([sheet_name,u'客户数',order_profile_dict[dict_key],dict_key+"_order.png"])
            #订单数
            dict_key = i+u"_订单数"
            order_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_id']
                        ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                       )
            df_rename(order_profile_dict[dict_key] ,table_nm=u"月订单数",col_nm=i,sub_nm=u'订单数',index_nm=u'月份')
            order_profile_list.append([sheet_name,u'订单数',order_profile_dict[dict_key],dict_key+"_order.png"])
            # 4.3.3 各区域月交易额
            #订单数
            dict_key = i+u"_交易额"
            order_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_amt']
                        ,aggfunc=[np.sum],fill_value=0,margins=False
                       )
            df_rename(order_profile_dict[dict_key],table_nm=u"月交易额",col_nm=i,sub_nm=u'交易额',index_nm=u'月份')
            order_profile_list.append([sheet_name,u'交易额',order_profile_dict[dict_key],dict_key+"_order.png"])
           # df_433 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_433',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__order_amt',method=u'sum',index_nm=u'月份',col_nm=u'各区域月交易额')
            # 4.3.4 各区域月单均价
            dict_key = i+u"_单均价"
            order_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_amt']
                        ,aggfunc=[np.average],fill_value=0,margins=False
                       )
            df_rename(order_profile_dict[dict_key],table_nm=u"月单均价",col_nm=i,sub_nm=u'交易额',index_nm=u'月份')
            order_profile_list.append([sheet_name,u'单均价',order_profile_dict[dict_key],dict_key+"_order.png"])

        cust_profile_list = []
        cust_profile_dict = {}
        for i in self.cust_profile_cols_list:
            sheet_name = u"客户属性_" + i
            #客户数
            dict_key = i+u"_客户数"
            cust_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns= i ,values=['__cust_id']
                    ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False)
            df_rename(cust_profile_dict[dict_key] ,table_nm=u"客户数",col_nm= i,sub_nm=u'交易客户数',index_nm=u'月份')
            cust_profile_list.append([sheet_name,u'客户数',cust_profile_dict[dict_key],dict_key+"_cust.png"])
            #订单数
            dict_key = i+u"_订单数"
            cust_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_id']
                        ,aggfunc=[pd.Series.nunique],fill_value=0,margins=False
                       )
            df_rename(cust_profile_dict[dict_key] ,table_nm=u"月订单数",col_nm=i,sub_nm=u'订单数',index_nm=u'月份')
            cust_profile_list.append([sheet_name,u'订单数',cust_profile_dict[dict_key],dict_key+"_cust.png"])
            # 4.3.3 各区域月交易额
            #订单数
            dict_key = i+u"_交易额"
            cust_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_amt']
                        ,aggfunc=[np.sum],fill_value=0,margins=False
                       )
            df_rename(cust_profile_dict[dict_key],table_nm=u"月交易额",col_nm=i,sub_nm=u'交易额',index_nm=u'月份')
            cust_profile_list.append([sheet_name,u'交易额',cust_profile_dict[dict_key],dict_key+"_cust.png"])
           # df_433 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_433',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__order_amt',method=u'sum',index_nm=u'月份',col_nm=u'各区域月交易额')
            # 4.3.4 各区域月单均价
            dict_key = i+u"_单均价"
            cust_profile_dict[dict_key] = pd.pivot_table(df_order_suss_info,index=['__order_time_mm'],columns=i,values=['__order_amt']
                        ,aggfunc=[np.average],fill_value=0,margins=False
                       )
            df_rename(cust_profile_dict[dict_key],table_nm=u"月单均价",col_nm=i,sub_nm=u'交易额',index_nm=u'月份')
            cust_profile_list.append([sheet_name,u'单均价',cust_profile_dict[dict_key],dict_key+"_cust.png"])


        # df_434 = cust_type_gb(df_in=df_order_suss_info,df_out=u'cust_run_434',clm_type=u'__order_time_mm',gb_nm=u'regn_city_x',gb_clm=u'__order_amt',gb_avg_cnt=u'__order_id',method=u'avg',index_nm=u'月份',col_nm=u'区域')
        print('4.3平台交易区域分析 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()


        #20170523增加 2.8 客户分层by 交易额，每一层客户客户量、月均交易额、交易额总额、平均注册时长
        #debug
        self.df_order_suss_info = df_order_suss_info
        df_511_grp = df_order_suss_info.groupby("__cust_id").agg({
        "__order_amt":np.sum,
        "__mob":np.max,
        "__order_time_mm": pd.Series.nunique}
        ).reset_index()
        #debug
        self.df_511_grp = df_511_grp
        df_511_grp["__order_amt_rank"] = (df_511_grp["__order_amt"].rank(method="min",na_option="bottom",ascending = False ,pct = True)/0.1).apply(mt.ceil)
        df_511_grp.rename(columns={u"__order_amt":u"订单金额",u"__mob":u"mob"},inplace=True)
        df_511_grp2=df_511_grp.groupby("__order_amt_rank").agg({u"订单金额":[np.max,np.min,np.mean,np.sum,np.median,np.size],
                                                                u"mob":[np.max,np.min,np.mean,np.median]
                                                                            })
        df_511_grp2[u"订单金额","sum_pct"]=df_511_grp2[u"订单金额","sum"]/df_511_grp2[u"订单金额","sum"].sum()
        df_511_grp2.index.name = u"客户总交易额分段"
        df_511_grp2=df_511_grp2.sort_index(level=0)
        df_511_grp2.columns.set_levels([u"最大",u"最小",u"平均",u"中位数",u"个数",u"汇总",u"汇总_pct"],level=1,inplace=True)
        df_208 = df_511_grp2

        #20170523增加 2.8 客户分层by 月均交易额，每一层客户客户量、月均交易额、交易额总额、平均注册时长-------------------------------------------------

        df_511_grp["__order_amt_byMonth"] = df_511_grp[u"订单金额"]/df_511_grp["__order_time_mm"]
        df_511_grp["__order_amt_byMonth_rank"] = (df_511_grp["__order_amt_byMonth"].rank(method="min",na_option="bottom",ascending = False ,pct = True)/0.1).apply(mt.ceil)

        df_511_grp3=df_511_grp.groupby("__order_amt_byMonth_rank").agg({u"订单金额":[np.max,np.min,np.mean,np.sum,np.median,np.size],
                                                                u"mob":[np.max,np.min,np.mean,np.median]
                                                                            })
        df_511_grp3[u"订单金额","sum_pct"]=df_511_grp3[u"订单金额","sum"]/df_511_grp3[u"订单金额","sum"].sum()
        df_511_grp3.index.name = u"客户交易月月交易额分段"
        df_511_grp3=df_511_grp3.sort_index(level=0)
        df_511_grp3.columns.set_levels([u"最大",u"最小",u"平均",u"中位数",u"个数",u"汇总",u"汇总_pct"],level=1,inplace=True)
        df_209 = df_511_grp3

        #20170802增加 按月生成趋势数据：成交订单数，买家客户数，买家客均订单数
        df_20170802 = df_order_suss_info.groupby(["__order_time_m"]).agg({"__order_id":pd.Series.nunique,"__cust_id":pd.Series.nunique}).reset_index()
        df_20170802.rename(columns = {"__order_time_m":u"交易月",
                             "__order_id":u"成交订单数",
                             "__cust_id": u"买家客户数",
                             },inplace = True)
        df_20170802[u"买家客均订单数"] = df_20170802[u"成交订单数"]/df_20170802[u"买家客户数"]
        df_20170802[u"交易月"] = df_20170802[u"交易月"].astype("string")

        #20170802增加 按月生成趋势数据：成交订单数，买家客户数，买家客均订单数
        #单均、客均、客交易月月均、客自然月月均
        list_q =map ((lambda x : x/10.0),list(range(0,11)))

        df_grp_cust = df_order_suss_info.groupby("__cust_id").agg({"__order_id":pd.Series.count,
                                                                  "__order_amt":np.sum,
                                                                  "__order_time_m":pd.Series.nunique})\
        .rename(columns = {"__order_id":"cust_order_id_cnt","__order_amt":"cust_order_amt_sum","__order_time_m":"cust_order_mth_cnt"})
        df_grp_cust["cust_order_sum_dealmth"] = df_grp_cust["cust_order_amt_sum"]/df_grp_cust["cust_order_mth_cnt"]
        df_grp_cust["cust_order_cnt_dealmth"] = df_grp_cust["cust_order_id_cnt"]/df_grp_cust["cust_order_mth_cnt"]
        s_order_amt = df_order_suss_info["__order_amt"].quantile(list_q).rename(u"订单金额")
        s_cust_grp = df_grp_cust.quantile(list_q).rename(columns = {
            "cust_order_id_cnt":u"客户订单数",
            "cust_order_mth_cnt":u"客户交易月",
            "cust_order_amt_sum":u"客户交易总额",
            "cust_order_sum_dealmth":u"客户交易月月均交易额",
            "cust_order_cnt_dealmth":u"客户交易月月均订单数"
        }
        )
        df_grp_plat = df_order_suss_info.groupby(["__order_time_m"]).agg({"__order_id":pd.Series.nunique,"__cust_id":pd.Series.nunique,"__order_amt":np.sum})
        s_plat_grp = df_grp_plat.quantile(list_q).rename(columns = {
            "__order_id":u"平台月订单数",
            "__cust_id":u"平台月客户数",
            "__order_amt":u"平台月交易额"
        })
        df_20170802_2 = pd.concat([s_plat_grp,s_cust_grp,s_order_amt],axis = 1)




        # 6.1 数据分析精简版
        df_order_suss_q = df_order_suss[(df_order_suss['__order_time_qq']>=max_order_qq)]
        plat_601 = plat_order(df=df_order_suss_q,method=u'count',gb_clm=u'__order_id',gb_out_nm=u'成交订单数',out_df_nm=u'plat_601',gb_nm=u'__order_time_qq')
        plat_602 = plat_order(df=df_order_suss_q,method=u'sum',out_df_nm=u'plat_602',gb_clm=u'__order_amt',gb_out_nm=u'成交订单金额',gb_nm=u'__order_time_qq')
        plat_603 = plat_order(df=df_order_suss_q,method=u'nunique',gb_clm=u'__order_time_mm',gb_out_nm=u'有交易月数',out_df_nm=u'plat_603',gb_nm=u'__order_time_qq')
        plat_604_x = plat_order(df=df_order_suss_q
                            ,method=u'sum'
                            ,out_df_nm=u'plat_504'
                            ,gb_clm=u'__order_amt'
                            ,gb_nm=['__cust_id','__order_time_mm','__order_time_qq']
                            ,gb_out_nm=u'cust_order_amt_mth').T.reset_index()
        plat_604 = plat_order(df=plat_604_x,method=u'avg',gb_clm=u'cust_order_amt_mth',gb_out_nm=u'客户月均交易金额',out_df_nm=u'plat_604',gb_nm=u'__order_time_qq')

        df_601 = pd.DataFrame()
        for i in range(1,5):
            if len(locals()["plat_%s" % (600+i)].columns) == 0:
                pass
            if len(locals()["plat_%s" % (600+i)].columns) > 0:
                if df_601.shape[0]!=0:
                    df_601 = df_601.append(locals()["plat_%s" % (600+i)])
                if df_601.shape[0]==0:
                    df_601 = locals()["plat_%s" % (600+i)]
        df_601.index.name = u'季度'
        # 数据输出
        self.report_list=[
            [u'2.1 平台交易概览',u'2.1 平台历史累计交易状况',df_201,""]
            ,[u'2.1 平台交易概览',u'2.2 平台交易客户活跃性——有交易月数',df_202,""]
            ,[u'2.1 平台交易概览',u'2.3 平台整体业务水平',df_203.T,"df_203.png"]
            ,[u'2.1 平台交易概览',u'2.4 订单金额区间-金额分布',df_204,""]
            ,[u'2.1 平台交易概览',u'2.5 订单金额区间-订单数分布',df_205,""]
            ,[u'2.1 平台交易概览',u'2.6 客户月交易金额区间金额分布',df_206,""]
            ,[u'2.1 平台交易概览',u'2.7 客户月交易订单数区间客户数分布',df_207,""]
            ,[u'2.1 平台交易概览',u'2.8 客户分层检视_总交易额',df_208,""]
            ,[u'2.1 平台交易概览',u'2.9 客户分层检视_交易月月交易额',df_209,""]
            ,[u'2.1 平台交易概览',u'2.10 平台月交易趋势',df_20170802,""]
            ,[u'2.1 平台交易概览',u'2.11 平台分位Profile',df_20170802_2,""]
            ,[u'3.1 客户基本属性分析', u'3.1.1 账户状态分布',df_311,""]
            ,[u'3.1 客户基本属性分析',u'3.1.2 客户类型1与注册时间分布',df_312,""]
            ,[u'3.1 客户基本属性分析',u'3.1.3 客户类型2与注册时间分布',df_313,""]
            ,[u'3.1 客户基本属性分析',u'3.1.4 客户状态与客户类型1分类',df_314,""]
            ,[u'3.1 客户基本属性分析',u'3.1.5 客户状态与客户类型2分类',df_315,""]
            ,[u'3.2 客户地域属性分析',u'3.2.1 城市与客户状态分布',df_321,""]
            ,[u'3.2 客户地域属性分析',u'3.2.2 城市与客户类型1分布',df_322,""]
            ,[u'3.2 客户地域属性分析',u'3.2.3 城市与客户类型2分布',df_323,""]
            ,[u'3.2 客户地域属性分析',u'3.2.4 城市与客户注册月份数分布',df_324,""]
            ,[u'3.2 客户地域属性分析',u'3.2.5 客户注册地区交易客户数分布',df_325,""]
            ,[u'3.2 客户地域属性分析',u'3.2.6 客户注册地区交易金额分布',df_326,""]
            ,[u'3.2 客户地域属性分析',u'3.2.7 客户注册地区交易订单数分布',df_327,""]
            ,[u'3.2 客户地域属性分析',u'3.2.8 客户注册地区交易单均交易额分布',df_328,""]
            ,[u'3.3 客户生命周期分析',u'3.3.1 客户生命周期分析',df_331,""]
            #to do add_some
            
            ,[u'3.3 客户生命周期分析',u'3.3.2客户生命周期-交易月份数分析',df_332,""]
            ,[u'4.1 平台交易客群分析',u'4.1.1 各客群交易客户数',df_411,""]
            ,[u'4.1 平台交易客群分析',u'4.1.2 各客群月订单数额',df_412,""]
            ,[u'4.1 平台交易客群分析',u'4.1.3 各客群月交易额',df_413,""]
            ,[u'4.1 平台交易客群分析',u'4.1.4 各客群月单均价',df_414,""]
            ,[u'4.1 平台交易客群分析',u'4.1.5 各客群交易客户数',df_415,""]
            ,[u'4.1 平台交易客群分析',u'4.1.6 各客群月订单数额',df_416,""]
            ,[u'4.1 平台交易客群分析',u'4.1.7 各客群月交易额',df_417,""]
            ,[u'4.1 平台交易客群分析',u'4.1.8 各客群月单均价',df_418,""]
            ,[u'4.2 平台交易商品分析',u'4.2.1 各商品类别月购买客户数',df_4201,""]
            ,[u'4.2 平台交易商品分析',u'4.2.2 各商品类别月订单数',df_4202,""]
            ,[u'4.2 平台交易商品分析',u'4.2.3 各商品类别月交易额',df_4203,""]
            ,[u'4.2 平台交易商品分析',u'4.2.4 各商品类别月单均价',df_4204,""]
            ,[u'4.2 平台交易商品分析',u'4.2.5 各商品类别单交易额金额区间订单数分布',df_4205,""]
            ,[u'4.2 平台交易商品分析',u'4.2.6 各商品类别单交易额金额区间金额分布',df_4206,""]
            ,[u'4.3 平台交易区域分析',u'4.3.1 各区域月客户数',df_431,""]
            ,[u'4.3 平台交易区域分析',u'4.3.2 各区域月订单数',df_432,""]
            ,[u'4.3 平台交易区域分析',u'4.3.3 各区域月交易额',df_433,""]
            ,[u'4.3 平台交易区域分析',u'4.3.4 各区域月单均价',df_434,""]
            ,[u'6.1 数据分析精简版',u'6.1 数据分析精简版',df_601,""]

        ] + order_profile_list + cust_profile_list
        #pd.to_msgpack(u"./output", self.report_list)
        ######################################################################
        #                          图片目录准备
        ######################################################################
        pic_dir_name = u"./output"
        if os.path.exists(pic_dir_name):
            print u"已有目录，准备清空"
            shutil.rmtree(pic_dir_name)
        #os.mkdir(pic_dir_name)
        print u"创建文件夹成功:" + pic_dir_name
        ######################################################################
        #                          作图并保存
        ######################################################################
        df = self.report_list[2][2]
        plot_cols = [u"买家客户数",u"成交订单数",u"成交订单金额",u"成交订单单均金额"]
        x_labels = pd.Series(df.index)
        fig,axes = pyplot.subplots(4,1)
        fig.set_size_inches(20,20)
        position = 0
        for col in plot_cols:
            position = position+1
            ax = pyplot.subplot(4,1,position)
            pyplot.plot(df[col].fillna(0).values,label = col)
            pyplot.legend()
            pyplot.xticks(range(len(x_labels)),x_labels)
            ret = pyplot.setp(ax.get_xticklabels(),rotation = 30 ,horizontalalignment = "right")
            for x,y in zip(range(len(x_labels)),df[col].fillna(0).values):
                pyplot.text(x,y,format(y,",.2f"))
        fig.savefig(pic_dir_name + "df_203.png")

        ######################################################################
        #                          分析简报：作图并保存——By HuHao
        ######################################################################
        print(u"简报：开始生成趋势图...")
        df_203t = df_203.T
        xtick = range(len(df_203t.index))
        xlabels = pd.Series(df_203t.index)
        fig = pyplot.figure()

        ax1 = fig.add_subplot(2,1,1)
        ax1.plot(xtick,df_203t[u"买家客户数"],"r",label=u"买家客户数")
        ax1.set_yticks([])
        ax1.legend(loc=2)

        ax2 = ax1.twinx()
        ax2.plot(xtick,df_203t[u"成交订单金额"],"g",label=u"成交订单金额")
        ax2.set_yticks([])
        ax2.legend(loc=1)

        ax1.set_xticks(xtick)
        ax1.set_xticklabels(xlabels)
        pyplot.setp(ax1.get_xticklabels(),rotation = 30 ,horizontalalignment = "right")

        ax1 = fig.add_subplot(2,1,2)
        ax1.plot(xtick,df_203t[u"买家客户数"],"r",label=u"买家客户数")
        ax1.set_yticks([])
        ax1.legend(loc=2)

        ax2 = ax1.twinx()
        ax2.plot(xtick,df_203t[u"买家客均成交订单数"],"g",label=u"买家客均成交订单数")
        ax2.set_yticks([])
        ax2.legend(loc=1)
        
        ax1.set_xticks(xtick)
        ax1.set_xticklabels(xlabels)
        pyplot.setp(ax1.get_xticklabels(),rotation = 30 ,horizontalalignment = "right")
        
        # fig.savefig(u"D:/数据分析/项目/P188_农淘网_huhao_test/1_原始数据/20170913/"+u'df_605.png')
        fig.set_size_inches(20,15)
        #plt.show()
        fig.savefig(pic_dir_name + "df_brief.png")

        print(u"简报：生成趋势图成功")

        ######################################################################
        #                          分析简报：客户交易情况简述——By HuHao
        ######################################################################
        df_607 = pd.DataFrame()

        lite_101_min = df_order.loc[(df_order["__order_sts"]==3),u"__order_amt"].min()
        lite_101_max = df_order.loc[(df_order["__order_sts"]==3),u"__order_amt"].max()
        lite_101 = pd.DataFrame(index=[1,],data={u"统计指标":u"单均价格区间（单位：元）",u"统计规则":u"最小-最大",u"统计值":str(lite_101_min)+"~"+str(lite_101_max)})
        
        lite_102_min = df_20170802_2.loc[0.1,u"订单金额"]
        lite_102_max = df_20170802_2.loc[0.9,u"订单金额"]
        lite_102 = pd.DataFrame(index=[2,],data={u"统计指标":u"单均价格主要区间（单位：元）",u"统计规则":u"覆盖80%左右订单量",u"统计值":str(lite_102_min)+"~"+str(lite_102_max)})
        
        lite_103_min = df_20170802_2.loc[0,u"客户交易月月均订单数"]
        lite_103_max = df_20170802_2.loc[1,u"客户交易月月均订单数"]
        lite_103 = pd.DataFrame(index=[3,],data={u"统计指标":u"客户月均成交订单量区间（单位：单）",u"统计规则":u"最小-最大",u"统计值":str(lite_103_min)+"~"+str(lite_103_max)})
        
        lite_104_min = df_20170802_2.loc[0.1,u"客户交易月月均订单数"]
        lite_104_max = df_20170802_2.loc[0.9,u"客户交易月月均订单数"]
        lite_104 = pd.DataFrame(index=[4,],data={u"统计指标":u"客户月均成交订单量主要区间（单位：单）",u"统计规则":u"覆盖80%左右有交易客户",u"统计值":str(lite_104_min)+"~"+str(lite_104_max)})
        
        lite_105_min = df_20170802_2.loc[0,u"客户交易月月均交易额"]
        lite_105_max = df_20170802_2.loc[1,u"客户交易月月均交易额"]
        lite_105 = pd.DataFrame(index=[5,],data={u"统计指标":u"客户月均交易额区间（单位：元）",u"统计规则":u"最小-最大",u"统计值":str(lite_105_min)+"~"+str(lite_105_max)})
        
        lite_106_min = df_20170802_2.loc[0.1,u"客户交易月月均交易额"]
        lite_106_max = df_20170802_2.loc[0.9,u"客户交易月月均交易额"]
        lite_106 = pd.DataFrame(index=[6,],data={u"统计指标":u"客户月均交易额主要区间（单位：元）",u"统计规则":u"覆盖80%左右有交易客户",u"统计值":str(lite_106_min)+"~"+str(lite_106_max)})
        
        lite_107 = pd.DataFrame(index=[7,],data={u"统计指标":u"客户月交易额度最大值（单位：元）",u"统计规则":u"所有数据最大值",u"统计值":lite_105_max})
        
        lite_108 = pd.DataFrame(index=[8,],data={u"统计指标":u"客户月交易额度最小值（单位：元）",u"统计规则":u"所有数据最小值",u"统计值":lite_105_min})
        
        lite_109_j = df_order_suss_info.groupby(["__order_time_m"]).agg({"__order_amt":np.sum})
        lite_109_z = df_order_suss_info.drop_duplicates(["__order_time_m"]).shape[0]

        lite_109_avg = round((sum(lite_109_j["__order_amt"])/lite_109_z)/10000)
        lite_109 = pd.DataFrame(index=[9,],data={u"统计指标":u"整体月均交易额（单位：万元）",u"统计规则":u"交易额累计/自然月累计",u"统计值":lite_109_avg})
        
        lite_110_max = round(df_20170802_2.loc[1,u"平台月交易额"]/10000)
        lite_110 = pd.DataFrame(index=[10,],data={u"统计指标":u"整体月最大交易额（单位：万元）",u"统计规则":u"最大月交易额",u"统计值":lite_110_max})
        
        lite_111_min = round(df_20170802_2.loc[0,u"平台月交易额"]/10000)
        lite_111 = pd.DataFrame(index=[11,],data={u"统计指标":u"整体月最小交易额（单位：万元）",u"统计规则":u"最小月交易额",u"统计值":lite_111_min})
        
        lite_112_mid = round(df_20170802_2.loc[0.5,u"平台月交易额"]/10000)
        lite_112 = pd.DataFrame(index=[12,],data={u"统计指标":u"整体月交易额中位数（单位：万元）",u"统计规则":u"按月统计交易额中位数",u"统计值":lite_112_mid})


        for i in range(1,13):
            if len(locals()["lite_%s" % (100+i)].columns) == 0:
                pass
            if len(locals()["lite_%s" % (100+i)].columns) > 0:
                if df_607.shape[0]!=0:
                    df_607 = df_607.append(locals()["lite_%s" % (100+i)])
                if df_607.shape[0]==0:
                    df_607 = locals()["lite_%s" % (100+i)]
        df_607.columns.name = u'序号'
        df_607 = df_607[[u"统计指标",u"统计规则",u"统计值"]]
        print(u"精简版生成完毕")
        self.brief_report = df_607
        #pd.to_msgpack(u"./output/"+self.ProjectName+u".msg",self.brief_report)            
        print('数据输出 用时----%sS'%((datetime.datetime.now() - starttime).seconds))
        starttime = datetime.datetime.now()
        wname = out_file_Path+ProjectName+u"_分析报告_"+self.getTimestr()+".xlsx"
        writeReport2(self.report_list,self.ProjectName,wname)
        print('写入excel 用时----%sS'%((datetime.datetime.now() - starttime).seconds))


    def genReport2(self):
        pass

#接收准入条件，生成授信profile


    def genCreditProfile(self, decline_rules_dict={}):
        df_rank = pd.DataFrame(
        {
        "creadit_rank_no":range(1,16),
        "credit_ranks":[
        'AAA+','AAA','AAA-','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB','B','C'
        ]#,
        #"credit_indexs":[1.5]*6+[1.3,1.2,1.1,1,0.9,0.8,0.6,0,0]
            }
        )
        df_final=self.cust_wide
        opd = df_final.merge(df_rank,how="left",left_on="credit_rank_no",
                                         right_on="creadit_rank_no")
        opd["is_Pass"]="Pass"
        is_Pass_col_list = ["is_Pass"]
        for k,v in decline_rules_dict.iteritems():
            opd.loc[v &(opd.is_Pass=="Pass"),"is_Pass"] = k
            col_name = "__is_Pass_"+str(k)
            is_Pass_col_list.append(col_name)
            opd.loc[:,col_name] = 1
            opd.loc[v,col_name] = 0
        ###投放概览           
        opd_pass_cnt = (opd.is_Pass == "Pass").sum()
        print u"总客户量:",opd.shape[0]
        print u"通过客户量:",opd_pass_cnt
        print u"通过率:",(opd_pass_cnt+0.0)/opd.shape[0]
        out_string = "总客户量： %s" % format(opd.shape[0],",") +"\n"+ \
                                        (u"通过客户量： %s" % format(opd_pass_cnt,",")) +"\n"+ \
                                        ("通过率： %.2f%%" % ((opd_pass_cnt+0.0)/opd.shape[0]*100))
        
        ####准入相关图
        opdd = opd[is_Pass_col_list]
        table_corr = opdd.corr()
        
        ####各条件情况
        sum_pass = opdd.drop("is_Pass",axis=1,errors="ignore").sum()
        sum_unpass = opdd.shape[0] - sum_pass
        table_rule_decline = pd.concat([sum_pass,sum_unpass],axis=1).rename(columns = {
            0:u"通过",
            1:u"拒绝"
        })

        #####各等级交易情况
        #各等级授信客户情况
        opd[u"reg_cnt_mth"]=opd[u"reg_cnt_mth"].apply(int)
        opd_grp = opd[opd["is_Pass"]=="Pass"].groupby(["credit_rank_no"]).agg({
        "credit_ranks":[np.max,pd.Series.count],
        "succ_order_amt_sum_3mth":[np.sum,np.mean],
        "succ_order_amt_sum_6mth":[np.sum,np.mean],
        "succ_order_amt_average_3mth": np.mean,
        "succ_order_amt_average_6mth": np.mean,
        "succ_avg_order_amt_monthly_3mth":np.mean,
        "succ_avg_order_amt_monthly_6mth":np.mean,
        "reg_cnt_mth":np.mean,
        "succ_order_amt_sum_hsty":[np.sum,np.mean],
        "succ_avg_order_amt_dealmonthly_hsty":np.mean
            }
        )
        
        opd_grp = opd_grp.rename(columns={
            "succ_order_amt_average_3mth":u"近3月单均金额均值",
            "succ_order_amt_average_6mth":u"近6月单均金额均值",
            "succ_order_amt_sum_3mth":u"近3月总金额",
            "succ_order_amt_sum_6mth":u"近6月总金额",
            "succ_avg_order_amt_monthly_3mth":u"近3月月均总金额",
            "succ_avg_order_amt_monthly_6mth":u"近6月月均总金额",
            "credit_ranks":u"授信等级",
            "reg_cnt_mth":u"注册月份数均值",
            "succ_order_amt_sum_hsty":u"历史交易总额",
            "succ_avg_order_amt_dealmonthly_hsty":u"历史月均交易额"
        })
        
        table_deal = opd_grp[[u"授信等级",u"注册月份数均值",u"近3月总金额",u"近6月总金额",u"历史交易总额",
                 u"近3月月均总金额",u"近6月月均总金额",u"历史月均交易额",u"近3月单均金额均值",
                 u"近6月单均金额均值"]]
        
        out_dict = {
                u"out_string":out_string,
                u"table_corr":table_corr,
                u"table_rule_decline":table_rule_decline,
                u"table_deal":table_deal
                }

        pd.to_msgpack(u"D:\\User\\zhangfengyi\\quant_station\\store_credit\\"+self.ProjectName+u".msg",out_dict)
        self.credit_profile = out_dict
        print u"授信完成，可通过Name.credit_profile查看概况"

print u"分析模块载入完成"
#测试代码

#导入计算包
