# -*- coding:utf-8 -*-
import numpy as np
import pandas as pd

def dataDict(tableDict):
    dataDict = pd.DataFrame()

    for k,v in tableDict.iteritems():
        #饱和度
        row_cnt = v.shape[0]
        row_nonnull_rt = (v.count()/row_cnt).reset_index().rename(columns={"index":u"列名",0:u"饱和度"})
        #唯一率
        row_distinct_rt = (v.apply(pd.Series.nunique)/row_cnt).reset_index().rename(columns = {"index":u"列名",0:u"唯一率"})
        #水平数
        row_nonnull = (v.count()).reset_index().rename(columns={"index":u"列名",0:u"水平数"})
        #唯一水平数
        row_distinct = (v.apply(pd.Series.nunique)).reset_index().rename(columns = {"index":u"列名",0:u"唯一水平数"})
        #数据类型
        columns = pd.Series(v.dtypes).reset_index()
        columns.rename(columns={u"index":u"列名",0:u"Python数据类型"},inplace=True)
        columns[u"Python数据类型"]=columns[u"Python数据类型"].apply(str)
        columns[u"HUE数据类型_推测"]=columns[u"Python数据类型"].map({
    "int64":"string",
    "object":"string",
    "float64":"string",
    "datetime64[ns]":"timestamp"
        })

        #columns.drop("index",axis=1,inplace=True)
        columns[u"表名"]=k
        columns = columns.merge(row_nonnull_rt,on=u"列名").merge(row_nonnull,on=u"列名").merge(row_distinct_rt,on=u"列名").merge(row_distinct,on=u"列名")
        columns.loc[(columns[u"饱和度"]==1)&(columns[u"唯一率"]==1),u"是否主键_推测"]=u"Y"
        sample= v.head(10).T
        #print list(sample.columns)
        sc = map(lambda x:"Sample "+str(x+1),list(sample.columns))
        sample.columns = sc

        #数值类型10decile取值统计
        #离散型，top 10 取值
        df_vc = pd.DataFrame()
        for i in v.columns:
            if ((columns[columns[u"列名"]==i][u"水平数"]==0).iloc[0]):
                continue
            if str(v[i].dtype) in ("int64","float64") and ((columns[columns[u"列名"]==i][u"唯一水平数"]>10).iloc[0]):

                #print k,i,v[i].dtype
                list_q =map ((lambda x : x/10.0),list(range(0,11)))
                df_quantile = v[i].quantile(list_q).reset_index().rename(columns = {"index":"top_pct"})
                df_quantile["top_pct"] = (df_quantile["top_pct"] * 10).apply(lambda x : str(int(x*10))+"_top_pct")
                df_quantile = df_quantile.set_index(df_quantile["top_pct"]).drop("top_pct",axis = 1).T
                df_quantile["row_name"]  = i
                #df_quantile["tab_name"] = k
                df_vc = df_vc.append(df_quantile)
            elif str(v[i].dtype) in ("object","int64","float64"):
                df_value_count = v[i].value_counts().reset_index().head(11)
                df_value_count["name_pct"] =  df_value_count[i]/row_cnt
                df_value_count["data_pct"] = df_value_count["index"].apply(str) + " cnt: " + \
                                            df_value_count[i].apply(str) + " pct: " + \
                                            df_value_count["name_pct"].apply(str)
                df_value_count["index"] = df_value_count.index
                df_value_count["index"] = df_value_count["index"].apply(lambda x : str(int(x*10))+"_top_pct")
                df_value_count = df_value_count.set_index(df_value_count["index"]).drop([i,"name_pct","index"],axis = 1).T
                df_value_count["row_name"] = i
                #df_value_count["tab_name"] = k
                df_vc = df_vc.append(df_value_count)
        columns = columns.merge(sample,how="left",left_on=u"列名",right_index=True)
        columns = columns.merge(df_vc,how="left",left_on=u"列名",right_on="row_name")
        dataDict = dataDict.append(columns)
    dataDict.drop(["row_name"],axis = 1,inplace = True)
    output_Columns = [
    u'表名',
    u'列名',
    u'Python数据类型',
    u'HUE数据类型_推测',
    u'饱和度',
    u'水平数',
    u'唯一率',
    u'唯一水平数',
    u'是否主键_推测',
    u'0_top_pct',
    u'10_top_pct',
    u'20_top_pct',
    u'30_top_pct',
    u'40_top_pct',
    u'50_top_pct',
    u'60_top_pct',
    u'70_top_pct',
    u'80_top_pct',
    u'90_top_pct',
    u'100_top_pct',
    u'Sample 1',
    u'Sample 2',
    u'Sample 3',
    u'Sample 4',
    u'Sample 5',
    u'Sample 6',
    u'Sample 7',
    u'Sample 8',
    u'Sample 9',
    u'Sample 10'
    ]

    #dataDict[output_Columns].to_csv(outputCsvPath,encoding="utf-8",index=False)
    #print outputCsvPath,u"-------生成完毕!"
    #print dataDict.columns
    return dataDict[output_Columns]
