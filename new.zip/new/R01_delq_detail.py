# -*- coding:utf-8 -*-
import numpy as np
import pandas as pd

from sqlalchemy import *
from sqlalchemy.engine import create_engine
from sqlalchemy.schema import *
from urllib import quote_plus as urlquote

password = "Casstime@0719"
engine = create_engine('mysql+pymysql://ximu:%s@cassec-demo-read.mysql.rds.aliyuncs.com:3306/ec_admin'%urlquote(password))

password = "Casstime@com1112"
engine2 = create_engine('mysql+pymysql://reader:%s@172.21.21.78:3306/kscredit'%urlquote(password))

def get_sql(sql,engine):
    df = pd.read_sql(sql=sql,con = engine)
    print df.shape
    print df.columns
    return df


sql = """-- 逾期
SELECT cust_code,
COUNT(1) AS delq_loan_cnt,
SUM(loan_bal)/100 AS delq_loan_bal,
MIN(loan_date) AS fst_delq_loan_date,
MIN(end_date) AS fst_delq_end_date
FROM kscredit_corebanking.ac_view_co_loan_bal
WHERE over_day > 0 AND loan_bal >0
GROUP BY cust_code;"""

df_delq_cust = get_sql(sql,engine2)

sql = """-- 余额
SELECT cust_code,
COUNT(1) AS bal_loan_cnt,
SUM(loan_bal)/100 AS loan_bal
FROM kscredit_corebanking.ac_view_co_loan_bal
WHERE loan_bal >0
GROUP BY cust_code;"""
df_bal_cust = get_sql(sql,engine2)

sql = """
SELECT t1.cust_code,t2.ett_mem_code,t3.cust_name 
FROM cust_member_info t1
LEFT JOIN cust_xm_ett_mem_rel t2
ON t1.mem_code = t2.xm_mem_code
LEFT JOIN cust_base_info t3
ON t1.cust_code = t3.cust_code
"""
df_cust_info = get_sql(sql,engine2)

sql = """
SELECT 
xm_list_code AS 徙木订单号,
cust_code 客户编号,
t2.product_name 产品,
loan_date 贷款日,
end_date 到期日,
loan_amt/100 AS 本金金额,
loan_bal/100 AS 本金余额,
over_day 逾期天数
FROM kscredit_corebanking.ac_view_co_loan_bal t1
LEFT JOIN kscredit_corebanking.product_base_info t2
ON t1.prod_code = t2.product_code
WHERE over_day > 0 AND loan_bal >0;
"""
df_delq_order = get_sql(sql,engine2)


df_merge = df_cust_info.merge(df_delq_cust,on = "cust_code",how="right").merge(df_bal_cust,on = "cust_code",how = "left")
df_merge = df_merge.rename(columns = {"cust_code":u"客户编号",
                                      "ett_mem_code":u"平台编号",
                                      "cust_name":u"客户名称",
                           "delq_loan_cnt":u"逾期订单数",
                           "delq_loan_bal":u"逾期余额",
                           "fst_delq_loan_date":u"逾期订单最早借款日",
                           "fst_delq_end_date":u"逾期订单最早到期日",
                           "bal_loan_cnt":u"余额订单数",
                           "loan_bal":u"余额"}).sort_values(by = u"逾期余额",ascending = False)

import datetime
dt = datetime.date.today()
dt_str = dt.strftime("%Y-%m-%d")
writer = pd.ExcelWriter(u'D:/casstime_ana/10_手工报表/R01_逾期明细/开思时代_逾期明细_%s.xlsx'%dt_str)
df_merge.to_excel(writer,sheet_name=u'逾期客户',index=False)
df_delq_order.to_excel(writer,sheet_name=u'逾期订单',index=False)
writer.save()
writer1 = pd.ExcelWriter(u'//10.118.71.218/徙木临时文件/R01_逾期明细/开思时代_逾期明细_%s.xlsx'%dt_str)
df_merge.to_excel(writer1,sheet_name=u'逾期客户',index=False)
df_delq_order.to_excel(writer1,sheet_name=u'逾期订单',index=False)
writer1.save()
