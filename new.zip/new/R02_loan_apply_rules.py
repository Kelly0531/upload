# -*- coding:utf-8 -*-
import pandas as pd
import numpy as np
from sqlalchemy import *
from sqlalchemy.engine import create_engine
from sqlalchemy.schema import *
from urllib import quote_plus as urlquote

# 全量明细list

password = "Casstime@0719"
engine = create_engine('mysql+pymysql://ximu:%s@cassec-demo-read.mysql.rds.aliyuncs.com:3306/ec_admin'%urlquote(password))

password = "Casstime@com1112"
engine2 = create_engine('mysql+pymysql://reader:%s@172.21.21.78:3306/kscredit'%urlquote(password))

def get_sql(sql,engine):
    df = pd.read_sql(sql=sql,con = engine)
    #print df.shape
    #print df.columns
    return df

sql_str = """
SELECT * FROM dsbs_apply_gds_screen_record
"""
df_loan_rules = get_sql(sql_str,engine2)

df_loan_rules["dsbs_scrn_feedback_desc"] = df_loan_rules["dsbs_scrn_feedback_desc"].fillna("")
df1 = pd.concat([pd.Series(row[u'dsbs_apply_no'], row['dsbs_scrn_feedback_desc']\
                            .split(';')) for _, row in df_loan_rules.iterrows()]).reset_index()
df1.columns = ["rules","dsbs_apply_no"]

mask = df1["rules"].str.contains(":") & (df1["rules"].str.contains("外部数据异常") == False)  \
             & (df1["rules"].str.contains("未获取到数据") == False) \
            & (df1["rules"].str.contains("数据格式") == False) \
                | (df1["rules"]=="") 
df1_f = df1[mask].copy()


df1_f["hit"] = 1
df_piv_rule = df1_f.pivot_table(index="dsbs_apply_no",columns = "rules",values="hit",aggfunc="count")
df_piv_rule.columns = pd.MultiIndex.from_product([[u"规则触发"],df_piv_rule.columns])


sql_str = u"""
SELECT t4.plfm_order_no as `订单编号`,
t1.cust_code as `客户编号`,t2.enterprise_name as `客户`,t3.fclt_name as `产品`,
t1.dsbs_apply_no,apply_amt/100 AS `金额`,
apply_begin_time AS `申请时间`,
CASE WHEN apply_status IN ("WAIT_XIMU","WAIT_FDING") THEN "待审核"
WHEN apply_status LIKE "REJECT%%" THEN "拒绝"
WHEN apply_status LIKE "DONE" THEN "通过"
WHEN apply_status LIKE "CANCEL" THEN "取消"
ELSE "其他" END AS `状态`
FROM dsbs_apply_info t1
LEFT JOIN  `cust_base_info_e` t2
ON t1.cust_code = t2.cust_code
LEFT JOIN fclt_base_info t3
ON t1.fclt_code = t3.fclt_code
left join dsbs_apply_order_info t4
on t1.dsbs_apply_no = t4.dsbs_apply_no
"""
df_loan_apply = get_sql(sql_str,engine2)
df_loan_apply = df_loan_apply.set_index("dsbs_apply_no")
dc = df_loan_apply.copy()
df_loan_apply.columns = pd.MultiIndex.from_product([[u"支用基本信息"],df_loan_apply.columns])

df_loan_apply_m = pd.concat([df_loan_apply,df_piv_rule],axis = 1,sort = False)
df_loan_apply_m.shape

df_loan_apply_m = df_loan_apply_m.sort_values(by = (u"支用基本信息",u"申请时间"),ascending = False)
import datetime
dt = datetime.date.today()
dt_str = dt.strftime("%Y-%m-%d")
df_loan_apply_m.to_excel(u"D:/casstime_ana/10_手工报表/R02_支用规则触发/开思_支用规则触发_"+dt_str+".xlsx")
df_loan_apply_m.to_excel(u"//10.118.71.218/徙木临时文件/R02_支用规则触发/开思_支用规则触发_"+dt_str+".xlsx")

##---------------------------------------------------------------------------------------------------##
# 触发率统计
df_loan_apply_m.columns = df_loan_apply_m.columns.droplevel()

tt = df_loan_apply_m.copy()
tt = tt.fillna(0)
tt['date'] = tt[u"申请时间"].dt.date
tt['date_str'] = tt[u"申请时间"].apply(lambda x:str(x))
tt['month'] = tt['date'].apply(lambda x:str(x)[:7])
tt=tt.reset_index()
tt["key"]=tt["index"]+tt[u"订单编号"]+tt[u"客户编号"]+tt["date_str"]
tt.index = tt["key"]

col = tt.columns.tolist()
#print(len(col))
col = col[9:]
col.remove('date')
col.remove('month')
col.remove('date_str')
col.remove('key')
#print(len(col))

ts = tt[col]
ts = ts.stack().reset_index().rename({"rules":"value"},axis = 1)
ts.columns=['key','rule','value']

tt= tt.drop('key',1)
tt=tt.reset_index()

ds = pd.merge(ts,tt,on = 'key',how = 'left')
 
ds['occ'] = 'casstime'
ds['customer'] = ds[u"客户编号"]
ds['dsbs_apply_no'] = ds[u"订单编号"]

order = ds.groupby(['month','date','occ']).agg({'key':pd.Series.nunique})
order = pd.DataFrame(order)
order = order.reset_index()

ss = ds.copy()
ss = ss[ss['value'] == 1]
# ss['value']=ss['value'].apply(lambda x:x if x == 1 else None)

result = ss.groupby(['month','date','occ','rule']).agg({'value':'sum','customer':pd.Series.nunique,'dsbs_apply_no':pd.Series.nunique})
result = pd.DataFrame(result)
result = result.reset_index()

total = pd.merge(result,order,on = ['month','date','occ'],how = 'left')
total['hit_ratio'] = np.round(total['value']/total['key'],4)

c = ['month','date','occ','rule','value','customer','dsbs_apply_no','hit_ratio']
ttl = total.loc[:,c]
ttl = ttl.sort_values(by='date',ascending = False)
ttl.columns = [u'统计月份',u'统计日期',u'场景',u'规则',u'触发次数',u'触发客户数',u'触发订单',u'触发率']

ttl.to_excel(u"D:/casstime_ana/10_手工报表/R02_支用规则触发/开思_支用规则触发_统计报表_"+dt_str+".xlsx")
ttl.to_excel(u"//10.118.71.218/徙木临时文件/R02_支用规则触发/开思_支用规则触发_统计报表_"+dt_str+".xlsx")